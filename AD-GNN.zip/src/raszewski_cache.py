"""Helpers for building and caching Raszewski investigation payloads."""

from __future__ import annotations

import hashlib
import json
import pickle
from pathlib import Path
from typing import Optional

import numpy as np
import pandas as pd
from scipy.sparse import csr_matrix, triu

from .features import extract_user_features, normalize_features
from .graphs import build_community_graph, build_graphs_adgnn

COORD_DELTA_SECONDS = 3600
COORD_MIN_WEIGHT = 2
COMM_MIN_WEIGHT = 2
COMM_SIMILARITY = "cosine"
TEMPORAL_DECAY = False
DECAY_LAMBDA = 0.1
BURST_THRESHOLD_SECONDS = 300
CACHE_VERSION = 1
FEATURE_NAMES = [
    "edit_count",
    "unique_pages",
    "pages_per_day",
    "temporal_spread",
    "activity_concentration",
]


def _cache_key(inv_path: Path, coord_method: str, coord_bucket_seconds: Optional[int]) -> tuple[str, dict]:
    stat = inv_path.stat()
    meta = {
        "cache_version": CACHE_VERSION,
        "path": str(inv_path),
        "size": stat.st_size,
        "mtime": stat.st_mtime,
        "coord_method": coord_method,
        "coord_bucket_seconds": coord_bucket_seconds,
        "coord_delta_seconds": COORD_DELTA_SECONDS,
        "coord_min_weight": COORD_MIN_WEIGHT,
        "comm_min_weight": COMM_MIN_WEIGHT,
        "comm_similarity": COMM_SIMILARITY,
        "temporal_decay": TEMPORAL_DECAY,
        "decay_lambda": DECAY_LAMBDA,
        "burst_threshold_seconds": BURST_THRESHOLD_SECONDS,
        "features": list(FEATURE_NAMES),
    }
    key = hashlib.sha1(json.dumps(meta, sort_keys=True).encode("utf-8")).hexdigest()[:12]
    return key, meta


def _load_cache(cache_path: Path, expected_meta: dict) -> Optional[dict]:
    if not cache_path.exists():
        return None
    try:
        with open(cache_path, "rb") as f:
            payload = pickle.load(f)
    except Exception:
        return None
    if payload.get("meta") != expected_meta:
        return None
    if "user_meta" not in payload:
        return None
    return payload


def _save_cache(cache_path: Path, payload: dict) -> None:
    cache_path.parent.mkdir(parents=True, exist_ok=True)
    with open(cache_path, "wb") as f:
        pickle.dump(payload, f, protocol=pickle.HIGHEST_PROTOCOL)


def build_coordination_graph_sparse(
    df: pd.DataFrame,
    delta_seconds: int = COORD_DELTA_SECONDS,
    min_weight: int = COORD_MIN_WEIGHT,
) -> pd.DataFrame:
    """Approximate bursty coordination via sparse user-(page,bucket) co-activity."""
    if df.empty:
        return pd.DataFrame(columns=["source", "target", "weight", "burst_count", "temporal_weight"])

    timestamps = pd.to_datetime(df["timestamp"])
    ts_sec = (timestamps.astype("int64") // 10**9).astype(np.int64)
    bucket = (ts_sec // delta_seconds).astype(np.int64)

    users = sorted(df["user_id"].unique(), key=str)
    user_to_idx = {u: i for i, u in enumerate(users)}
    rows = df["user_id"].map(user_to_idx).values

    page_codes, _ = pd.factorize(df["page_id"], sort=False)
    group_codes, _ = pd.factorize(pd.MultiIndex.from_arrays([page_codes, bucket]), sort=False)

    pairs = np.column_stack([rows, group_codes])
    pairs = np.unique(pairs, axis=0)

    X = csr_matrix(
        (np.ones(len(pairs), dtype=np.float32), (pairs[:, 0], pairs[:, 1])),
        shape=(len(users), int(group_codes.max() + 1)),
        dtype=np.float32,
    )

    W = X @ X.T
    W.setdiag(0)
    W.eliminate_zeros()

    W_upper = triu(W, k=1)
    edge_rows, edge_cols = W_upper.nonzero()
    weights = W_upper.data

    mask = weights >= min_weight
    edge_rows = edge_rows[mask]
    edge_cols = edge_cols[mask]
    weights = weights[mask]

    edges = pd.DataFrame(
        {
            "source": [users[i] for i in edge_rows],
            "target": [users[i] for i in edge_cols],
            "weight": weights,
        }
    )
    if edges.empty:
        return pd.DataFrame(columns=["source", "target", "weight", "burst_count", "temporal_weight"])

    edges["burst_count"] = 0.0
    edges["temporal_weight"] = edges["weight"].astype(float)
    return edges


def build_or_load_raszewski_payload(
    inv_path: Path,
    coord_method: str = "sparse",
    coord_bucket_seconds: Optional[int] = None,
    cache_dir: Optional[Path] = None,
    use_cache: bool = True,
) -> dict:
    """Build or load the cached payload used by Raszewski evaluation scripts."""
    inv_path = Path(inv_path)
    cache_dir = Path(cache_dir) if cache_dir is not None else None

    cache_path = None
    expected_meta = None
    if cache_dir is not None:
        key, expected_meta = _cache_key(inv_path, coord_method, coord_bucket_seconds)
        cache_path = cache_dir / f"{inv_path.stem}_{key}.pkl"
        if use_cache:
            cached = _load_cache(cache_path, expected_meta)
            if cached is not None:
                return cached

    df = pd.read_csv(inv_path)
    work_df = df.copy()
    work_df["timestamp"] = pd.to_datetime(
        work_df["timestamp"], format="mixed", utc=True, errors="coerce"
    )
    work_df = work_df.dropna(subset=["timestamp"]).copy()
    work_df["user_id"] = work_df["user"].astype(str)
    work_df["page_id"] = work_df["page"].astype(str)

    if coord_method == "sparse":
        comm_edges = build_community_graph(
            work_df,
            min_weight=COMM_MIN_WEIGHT,
            similarity=COMM_SIMILARITY,
            temporal_decay=TEMPORAL_DECAY,
            decay_lambda=DECAY_LAMBDA,
        )
        coord_edges = build_coordination_graph_sparse(
            work_df,
            delta_seconds=coord_bucket_seconds or COORD_DELTA_SECONDS,
            min_weight=COORD_MIN_WEIGHT,
        )
        comm_edges, coord_edges = coord_edges, comm_edges
    else:
        comm_edges, coord_edges = build_graphs_adgnn(
            work_df,
            coord_delta_seconds=COORD_DELTA_SECONDS,
            coord_min_weight=COORD_MIN_WEIGHT,
            comm_min_weight=COMM_MIN_WEIGHT,
            comm_similarity=COMM_SIMILARITY,
            temporal_decay=TEMPORAL_DECAY,
            decay_lambda=DECAY_LAMBDA,
            burst_threshold_seconds=BURST_THRESHOLD_SECONDS,
        )

    user_features = normalize_features(extract_user_features(work_df, FEATURE_NAMES))
    counts = work_df.groupby("user_id").size()
    user_sock = df.groupby("user")["sock"].max()
    user_meta = {
        str(user): {"sock": int(user_sock.get(user, 0)), "count": int(counts.get(user, 0))}
        for user in sorted(set(work_df["user_id"]))
    }

    payload = {
        "meta": expected_meta,
        "comm_edges": comm_edges,
        "coord_edges": coord_edges,
        "user_features": user_features,
        "user_meta": user_meta,
    }

    if use_cache and cache_path is not None:
        _save_cache(cache_path, payload)

    return payload
