"""Input/output utilities for activity log data."""

from pathlib import Path
from typing import Optional, Union

import pandas as pd


def read_activity_log(
    path: Union[str, Path],
    event_type_col: Optional[str] = None,
    bytes_added_col: Optional[str] = None,
    bytes_removed_col: Optional[str] = None,
    is_reverted_col: Optional[str] = None,
) -> pd.DataFrame:
    """
    Read and validate activity log.

    Input schema:
        Required columns:
            - user_id (str/int)
            - page_id (str/int)
            - timestamp (ISO8601 string or unix seconds)

        Optional columns (specify via parameters):
            - event_type
            - bytes_added
            - bytes_removed
            - is_reverted

    Parameters
    ----------
    path : str or Path
        Path to activity log CSV or Parquet file.
    event_type_col : str, optional
        Name of event type column if present.
    bytes_added_col : str, optional
        Name of bytes added column if present.
    bytes_removed_col : str, optional
        Name of bytes removed column if present.
    is_reverted_col : str, optional
        Name of is_reverted boolean column if present.

    Returns
    -------
    pd.DataFrame
        Validated activity log with standardized columns.

    Raises
    ------
    ValueError
        If required columns are missing or data is invalid.
    """
    path = Path(path)

    # Read file based on extension
    if path.suffix == ".parquet":
        df = pd.read_parquet(path)
    elif path.suffix == ".csv":
        df = pd.read_csv(path)
    else:
        raise ValueError(f"Unsupported file format: {path.suffix}. Use .csv or .parquet")

    # Validate required columns
    required_cols = {"user_id", "page_id", "timestamp"}
    missing_cols = required_cols - set(df.columns)
    if missing_cols:
        raise ValueError(f"Missing required columns: {missing_cols}")

    # Convert timestamp to datetime
    if not pd.api.types.is_datetime64_any_dtype(df["timestamp"]):
        # Try parsing as ISO8601 first, then as unix seconds
        try:
            df["timestamp"] = pd.to_datetime(df["timestamp"])
        except Exception:
            try:
                df["timestamp"] = pd.to_datetime(df["timestamp"], unit="s")
            except Exception as e:
                raise ValueError(f"Failed to parse timestamp column: {e}") from e

    # Ensure user_id and page_id are strings for consistency
    df["user_id"] = df["user_id"].astype(str)
    df["page_id"] = df["page_id"].astype(str)

    # Sort by timestamp
    df = df.sort_values("timestamp").reset_index(drop=True)

    # Validate optional columns
    optional_mapping = {
        "event_type": event_type_col,
        "bytes_added": bytes_added_col,
        "bytes_removed": bytes_removed_col,
        "is_reverted": is_reverted_col,
    }

    for std_name, user_col in optional_mapping.items():
        if user_col and user_col in df.columns:
            df[std_name] = df[user_col]
            if user_col != std_name:
                df = df.drop(columns=[user_col])

    return df


def validate_activity_log(df: pd.DataFrame) -> None:
    """
    Validate activity log DataFrame.

    Parameters
    ----------
    df : pd.DataFrame
        Activity log to validate.

    Raises
    ------
    ValueError
        If validation fails.
    """
    # Check for required columns
    required_cols = {"user_id", "page_id", "timestamp"}
    missing_cols = required_cols - set(df.columns)
    if missing_cols:
        raise ValueError(f"Missing required columns: {missing_cols}")

    # Check for nulls in required columns
    for col in required_cols:
        null_count = df[col].isnull().sum()
        if null_count > 0:
            raise ValueError(f"Column {col} has {null_count} null values")

    # Check timestamp is datetime
    if not pd.api.types.is_datetime64_any_dtype(df["timestamp"]):
        raise ValueError("timestamp column must be datetime64 dtype")

    # Check for duplicate events (same user, page, timestamp)
    dup_count = df.duplicated(subset=["user_id", "page_id", "timestamp"]).sum()
    if dup_count > 0:
        raise ValueError(
            f"Found {dup_count} duplicate events (same user, page, timestamp). "
            "Please deduplicate before processing."
        )


def save_edge_list(
    edges: pd.DataFrame, path: Union[str, Path], fmt: str = "csv"
) -> None:
    """
    Save edge list to file.

    Parameters
    ----------
    edges : pd.DataFrame
        Edge list with columns (source, target, weight).
    path : str or Path
        Output path.
    fmt : str
        Output format: 'csv' or 'parquet'.
    """
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)

    if fmt == "csv":
        edges.to_csv(path, index=False)
    elif fmt == "parquet":
        edges.to_parquet(path, index=False)
    else:
        raise ValueError(f"Unsupported format: {fmt}")


def load_edge_list(path: Union[str, Path]) -> pd.DataFrame:
    """
    Load edge list from file.

    Parameters
    ----------
    path : str or Path
        Path to edge list file.

    Returns
    -------
    pd.DataFrame
        Edge list with columns (source, target, weight).
    """
    path = Path(path)

    if path.suffix == ".parquet":
        return pd.read_parquet(path)
    elif path.suffix == ".csv":
        return pd.read_csv(path)
    else:
        raise ValueError(f"Unsupported file format: {path.suffix}")
