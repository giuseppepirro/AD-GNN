"""Feature extraction for Path B deep learning model."""

from typing import Dict, List

import numpy as np
import pandas as pd


def extract_user_features(
    df: pd.DataFrame, feature_names: List[str]
) -> Dict[str, np.ndarray]:
    """
    Extract user-level features from activity log.

    Parameters
    ----------
    df : pd.DataFrame
        Activity log for a time window.
    feature_names : List[str]
        List of features to extract.

    Returns
    -------
    Dict[str, np.ndarray]
        Dictionary mapping user_id to feature vector.
    """
    # Group by user
    user_groups = df.groupby("user_id")

    features_dict = {}

    for user_id, user_df in user_groups:
        feature_vec = []

        for feat_name in feature_names:
            if feat_name == "edit_count":
                val = len(user_df)

            elif feat_name == "unique_pages":
                val = user_df["page_id"].nunique()

            elif feat_name == "pages_per_day":
                time_span = (user_df["timestamp"].max() - user_df["timestamp"].min()).total_seconds()
                days = max(time_span / 86400, 1e-6)  # avoid division by zero
                val = user_df["page_id"].nunique() / days

            elif feat_name == "mean_inter_event_time":
                if len(user_df) > 1:
                    sorted_times = user_df["timestamp"].sort_values()
                    inter_times = sorted_times.diff().dt.total_seconds().dropna()
                    val = inter_times.mean() if len(inter_times) > 0 else 0.0
                else:
                    val = 0.0

            elif feat_name == "burstiness":
                if len(user_df) > 1:
                    sorted_times = user_df["timestamp"].sort_values()
                    inter_times = sorted_times.diff().dt.total_seconds().dropna()
                    if len(inter_times) > 0:
                        mean_time = inter_times.mean()
                        std_time = inter_times.std()
                        val = std_time / max(mean_time, 1e-6)
                    else:
                        val = 0.0
                else:
                    val = 0.0

            elif feat_name == "temporal_spread":
                # Temporal spread: standard deviation of timestamps (in days)
                if len(user_df) > 1:
                    timestamps = user_df["timestamp"]
                    time_diffs = (timestamps - timestamps.min()).dt.total_seconds() / 86400
                    val = time_diffs.std()
                else:
                    val = 0.0

            elif feat_name == "early_activity_ratio":
                # Fraction of edits in the first half of the window
                if len(user_df) > 0:
                    min_time = user_df["timestamp"].min()
                    max_time = user_df["timestamp"].max()
                    mid_time = min_time + (max_time - min_time) / 2
                    early_count = (user_df["timestamp"] <= mid_time).sum()
                    val = early_count / len(user_df)
                else:
                    val = 0.0

            elif feat_name == "late_activity_ratio":
                # Fraction of edits in the second half of the window
                if len(user_df) > 0:
                    min_time = user_df["timestamp"].min()
                    max_time = user_df["timestamp"].max()
                    mid_time = min_time + (max_time - min_time) / 2
                    late_count = (user_df["timestamp"] > mid_time).sum()
                    val = late_count / len(user_df)
                else:
                    val = 0.0

            elif feat_name == "activity_concentration":
                # Gini coefficient of temporal distribution (0 = uniform, 1 = concentrated)
                if len(user_df) > 1:
                    timestamps = user_df["timestamp"].sort_values()
                    time_diffs = timestamps.diff().dt.total_seconds().dropna()
                    if len(time_diffs) > 0:
                        # Gini coefficient calculation
                        sorted_diffs = np.sort(time_diffs)
                        n = len(sorted_diffs)
                        cumsum = np.cumsum(sorted_diffs)
                        if cumsum[-1] > 0:
                            val = (2 * np.sum((np.arange(1, n + 1)) * sorted_diffs) / (n * cumsum[-1])) - (n + 1) / n
                        else:
                            val = 0.0
                    else:
                        val = 0.0
                else:
                    val = 0.0

            elif feat_name == "time_since_first_edit":
                # Time since first edit in the window (in days, relative to window end)
                if len(user_df) > 0:
                    # Get window end from the dataframe
                    window_end = user_df["timestamp"].max()
                    first_edit = user_df["timestamp"].min()
                    val = (window_end - first_edit).total_seconds() / 86400
                else:
                    val = 0.0

            elif feat_name == "time_to_last_edit":
                # Time to last edit in the window (in days, relative to window start)
                if len(user_df) > 0:
                    window_start = user_df["timestamp"].min()
                    last_edit = user_df["timestamp"].max()
                    val = (last_edit - window_start).total_seconds() / 86400
                else:
                    val = 0.0

            elif feat_name == "revert_rate" and "is_reverted" in user_df.columns:
                val = user_df["is_reverted"].mean()

            elif feat_name == "bytes_added_mean" and "bytes_added" in user_df.columns:
                val = user_df["bytes_added"].mean()

            elif feat_name == "bytes_removed_mean" and "bytes_removed" in user_df.columns:
                val = user_df["bytes_removed"].mean()

            else:
                val = 0.0  # Unknown feature

            if not np.isfinite(val):
                val = 0.0

            feature_vec.append(val)

        features_dict[user_id] = np.array(feature_vec, dtype=np.float32)

    return features_dict


def normalize_features(
    features_dict: Dict[str, np.ndarray]
) -> Dict[str, np.ndarray]:
    """
    Normalize features to zero mean and unit variance.

    Parameters
    ----------
    features_dict : Dict[str, np.ndarray]
        User features.

    Returns
    -------
    Dict[str, np.ndarray]
        Normalized features.
    """
    if not features_dict:
        return {}

    # Stack all features
    user_ids = sorted(features_dict.keys())
    feature_matrix = np.stack([features_dict[uid] for uid in user_ids], axis=0)

    # Compute mean and std
    mean = feature_matrix.mean(axis=0)
    std = feature_matrix.std(axis=0)
    std = np.where(std < 1e-6, 1.0, std)  # avoid division by zero

    # Normalize
    normalized_matrix = (feature_matrix - mean) / std

    # Convert back to dict
    normalized_dict = {
        uid: normalized_matrix[i] for i, uid in enumerate(user_ids)
    }

    return normalized_dict


def features_to_tensor(
    features_dict: Dict[str, np.ndarray], users: List[str]
) -> np.ndarray:
    """
    Convert features dict to tensor with specified user ordering.

    Parameters
    ----------
    features_dict : Dict[str, np.ndarray]
        User features.
    users : List[str]
        Ordered list of user IDs.

    Returns
    -------
    np.ndarray
        Feature matrix of shape (num_users, num_features).
    """
    if not users:
        return np.zeros((0, 0), dtype=np.float32)

    # Get feature dimension
    feat_dim = len(next(iter(features_dict.values())))

    # Build matrix
    feature_matrix = np.zeros((len(users), feat_dim), dtype=np.float32)

    for i, user in enumerate(users):
        if user in features_dict:
            feature_matrix[i] = features_dict[user]

    return feature_matrix
