"""Graph construction from activity logs with temporal features."""

from typing import Dict, Literal, Tuple, Optional

import numpy as np
import pandas as pd
from scipy.sparse import csr_matrix
from scipy.sparse import triu


def build_community_graph(
    df: pd.DataFrame,
    min_weight: int = 2,
    similarity: Literal["raw", "cosine", "jaccard"] = "cosine",
    temporal_decay: bool = False,
    decay_lambda: float = 0.1,
) -> pd.DataFrame:
    """
    Build community graph G_comm based on co-edit similarity.

    Uses user-page incidence matrix to compute co-edit weights efficiently.
    Optionally applies temporal decay to weight recent interactions more heavily.

    Parameters
    ----------
    df : pd.DataFrame
        Activity log for a time window with columns (user_id, page_id, timestamp).
    min_weight : int
        Minimum edge weight to keep.
    similarity : str
        Similarity metric: 'raw' (count), 'cosine', or 'jaccard'.
    temporal_decay : bool
        If True, apply exponential temporal decay to edge weights.
    decay_lambda : float
        Decay rate parameter (higher = faster decay). Only used if temporal_decay=True.

    Returns
    -------
    pd.DataFrame
        Edge list with columns (source, target, weight, temporal_weight).
    """
    # Create user and page indices
    users = sorted(df["user_id"].unique())
    pages = sorted(df["page_id"].unique())

    user_to_idx = {u: i for i, u in enumerate(users)}
    page_to_idx = {p: i for i, p in enumerate(pages)}

    # Build user-page incidence matrix (binary)
    rows = df["user_id"].map(user_to_idx).values
    cols = df["page_id"].map(page_to_idx).values
    data = np.ones(len(df), dtype=np.int32)

    # Use groupby to handle duplicate (user, page) pairs
    row_col_pairs = pd.DataFrame({"row": rows, "col": cols, "data": data})
    row_col_pairs = row_col_pairs.groupby(["row", "col"], as_index=False).sum()

    X = csr_matrix(
        (row_col_pairs["data"].values, (row_col_pairs["row"].values, row_col_pairs["col"].values)),
        shape=(len(users), len(pages)),
        dtype=np.float32,
    )

    # Compute co-edit matrix: W = X @ X.T
    W = X @ X.T

    # Remove diagonal (self-loops)
    W.setdiag(0)
    W.eliminate_zeros()

    # Apply similarity metric
    if similarity == "cosine":
        # Cosine similarity: normalize by sqrt(degree)
        degrees = np.array(X.sum(axis=1)).flatten()
        degrees = np.maximum(degrees, 1e-8)  # avoid division by zero
        D_inv_sqrt = csr_matrix(np.diag(1.0 / np.sqrt(degrees)))
        W = D_inv_sqrt @ W @ D_inv_sqrt
        W.eliminate_zeros()

    elif similarity == "jaccard":
        # Jaccard: |A ∩ B| / |A ∪ B|
        # |A ∪ B| = |A| + |B| - |A ∩ B|
        degrees = np.array(X.sum(axis=1)).flatten()
        W_dense = W.toarray()
        for i in range(len(users)):
            for j in range(i + 1, len(users)):
                if W_dense[i, j] > 0:
                    intersection = W_dense[i, j]
                    union = degrees[i] + degrees[j] - intersection
                    W_dense[i, j] = intersection / max(union, 1.0)
                    W_dense[j, i] = W_dense[i, j]
        W = csr_matrix(W_dense)
        W.eliminate_zeros()

    # Extract upper triangle (undirected graph)
    W_upper = triu(W, k=1)

    # Convert to edge list
    rows, cols = W_upper.nonzero()
    weights = W_upper.data

    # Filter by minimum weight
    mask = weights >= min_weight
    rows = rows[mask]
    cols = cols[mask]
    weights = weights[mask]

    # Map indices back to user IDs
    edges = pd.DataFrame({
        "source": [users[i] for i in rows],
        "target": [users[i] for i in cols],
        "weight": weights,
    })

    # Apply temporal decay if requested
    if temporal_decay and not edges.empty:
        # Compute temporal weights based on edge recency
        window_end = df["timestamp"].max()

        # For each edge, compute average timestamp of shared page edits
        edge_timestamps = []
        for idx, row in edges.iterrows():
            u, v = row["source"], row["target"]
            # Find pages edited by both users
            u_pages = set(df[df["user_id"] == u]["page_id"])
            v_pages = set(df[df["user_id"] == v]["page_id"])
            shared_pages = u_pages & v_pages

            # Get timestamps of edits on shared pages
            shared_edits = df[
                (df["page_id"].isin(shared_pages)) &
                (df["user_id"].isin([u, v]))
            ]
            avg_timestamp = shared_edits["timestamp"].mean()
            edge_timestamps.append(avg_timestamp)

        # Compute temporal decay weights
        edges["avg_timestamp"] = edge_timestamps
        edges["time_age_days"] = (window_end - edges["avg_timestamp"]).dt.total_seconds() / 86400
        edges["temporal_weight"] = edges["weight"] * np.exp(-decay_lambda * edges["time_age_days"])

        # Use temporal weight as the primary weight
        edges["weight"] = edges["temporal_weight"]
        edges = edges.drop(columns=["avg_timestamp", "time_age_days"])
    else:
        edges["temporal_weight"] = edges["weight"]

    return edges


def build_coordination_graph(
    df: pd.DataFrame,
    delta_seconds: int = 3600,
    min_weight: int = 2,
    burst_threshold_seconds: int = 300,
    temporal_decay: bool = False,
    decay_lambda: float = 0.1,
) -> pd.DataFrame:
    """
    Build coordination graph G_coord based on bursty co-activity.

    Uses page-wise two-pointer sliding window for efficiency.
    Detects burst edits (rapid coordination) and optionally applies temporal decay.

    Parameters
    ----------
    df : pd.DataFrame
        Activity log for a time window with columns (user_id, page_id, timestamp).
    delta_seconds : int
        Time window for coordination (in seconds).
    min_weight : int
        Minimum edge weight to keep.
    burst_threshold_seconds : int
        Time threshold for burst detection (edits within this window are marked as bursts).
    temporal_decay : bool
        If True, apply exponential temporal decay to edge weights.
    decay_lambda : float
        Decay rate parameter. Only used if temporal_decay=True.

    Returns
    -------
    pd.DataFrame
        Edge list with columns (source, target, weight, burst_count, temporal_weight).
    """
    # Convert delta to timedelta
    delta = pd.Timedelta(seconds=delta_seconds)
    burst_delta = pd.Timedelta(seconds=burst_threshold_seconds)

    # Group by page
    grouped = df.groupby("page_id")

    # Track coordination counts and burst edits between user pairs
    coord_counts: Dict[Tuple[str, str], int] = {}
    burst_counts: Dict[Tuple[str, str], int] = {}
    edge_timestamps: Dict[Tuple[str, str], List[pd.Timestamp]] = {}

    for page_id, page_df in grouped:
        # Sort by timestamp
        page_df = page_df.sort_values("timestamp").reset_index(drop=True)
        events = page_df[["user_id", "timestamp"]].values

        n = len(events)

        # Two-pointer sliding window
        for i in range(n):
            user_i = events[i, 0]
            time_i = events[i, 1]

            # Find all events within delta
            j = i + 1
            users_in_window = set()
            burst_users = set()

            while j < n and (events[j, 1] - time_i) <= delta:
                users_in_window.add(events[j, 0])
                # Check if this is a burst edit (within burst threshold)
                if (events[j, 1] - time_i) <= burst_delta:
                    burst_users.add(events[j, 0])
                j += 1

            # Count coordination with each unique user in window
            # Only count once per (user_i, user_j, page) to avoid double-counting
            for user_j in users_in_window:
                if user_i != user_j:
                    # Canonical ordering for undirected edges
                    edge = tuple(sorted([user_i, user_j]))
                    coord_counts[edge] = coord_counts.get(edge, 0) + 1

                    # Track burst edits
                    if user_j in burst_users:
                        burst_counts[edge] = burst_counts.get(edge, 0) + 1

                    # Track timestamps for temporal decay
                    if edge not in edge_timestamps:
                        edge_timestamps[edge] = []
                    edge_timestamps[edge].append(time_i)

    # Convert to edge list
    edges_list = []
    window_end = df["timestamp"].max()

    for (u, v), weight in coord_counts.items():
        if weight >= min_weight:
            edge_data = {
                "source": u,
                "target": v,
                "weight": weight,
                "burst_count": burst_counts.get((u, v), 0),
            }

            # Add temporal decay if requested
            if temporal_decay:
                # Average timestamp of coordinated edits
                avg_timestamp = pd.Timestamp(np.mean([ts.value for ts in edge_timestamps[(u, v)]]))
                time_age_days = (window_end - avg_timestamp).total_seconds() / 86400
                temporal_weight = weight * np.exp(-decay_lambda * time_age_days)
                edge_data["temporal_weight"] = temporal_weight
            else:
                edge_data["temporal_weight"] = float(weight)

            edges_list.append(edge_data)

    edges = pd.DataFrame(edges_list)

    if edges.empty:
        return pd.DataFrame(columns=["source", "target", "weight", "burst_count", "temporal_weight"])

    return edges


def build_graphs(
    df: pd.DataFrame,
    coord_delta_seconds: int = 3600,
    coord_min_weight: int = 2,
    comm_min_weight: int = 2,
    comm_similarity: Literal["raw", "cosine", "jaccard"] = "cosine",
    temporal_decay: bool = False,
    decay_lambda: float = 0.1,
    burst_threshold_seconds: int = 300,
    paradox_alignment: bool = False,
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """
    Build both community and coordination graphs with optional temporal features.

    Parameters
    ----------
    df : pd.DataFrame
        Activity log for a time window.
    coord_delta_seconds : int
        Time window for coordination.
    coord_min_weight : int
        Minimum coordination edge weight.
    comm_min_weight : int
        Minimum community edge weight.
    comm_similarity : str
        Community graph similarity metric.
    temporal_decay : bool
        If True, apply exponential temporal decay to edge weights.
    decay_lambda : float
        Decay rate parameter for temporal decay.
    burst_threshold_seconds : int
        Time threshold for burst detection in coordination graphs.

    Returns
    -------
    comm_edges : pd.DataFrame
        Community graph edge list with temporal features.
    coord_edges : pd.DataFrame
        Coordination graph edge list with temporal features.
    """
    comm_edges = build_community_graph(
        df,
        min_weight=comm_min_weight,
        similarity=comm_similarity,
        temporal_decay=temporal_decay,
        decay_lambda=decay_lambda,
    )

    coord_edges = build_coordination_graph(
        df,
        delta_seconds=coord_delta_seconds,
        min_weight=coord_min_weight,
        burst_threshold_seconds=burst_threshold_seconds,
        temporal_decay=temporal_decay,
        decay_lambda=decay_lambda,
    )

    if paradox_alignment:
        # For AD-GNN, treat coordination as long-term similarity (community graph)
        # and communication as short-term burst coordination (coordination graph).
        return coord_edges, comm_edges

    return comm_edges, coord_edges


def build_graphs_adgnn(
    df: pd.DataFrame,
    coord_delta_seconds: int = 3600,
    coord_min_weight: int = 2,
    comm_min_weight: int = 2,
    comm_similarity: Literal["raw", "cosine", "jaccard"] = "cosine",
    temporal_decay: bool = False,
    decay_lambda: float = 0.1,
    burst_threshold_seconds: int = 300,
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """
    Build graphs with AD-GNN paradox alignment.

    Returns:
        comm_edges: bursty coordination (proxy for direct communication)
        coord_edges: long-term co-edit similarity (coordination signal)
    """
    return build_graphs(
        df,
        coord_delta_seconds=coord_delta_seconds,
        coord_min_weight=coord_min_weight,
        comm_min_weight=comm_min_weight,
        comm_similarity=comm_similarity,
        temporal_decay=temporal_decay,
        decay_lambda=decay_lambda,
        burst_threshold_seconds=burst_threshold_seconds,
        paradox_alignment=True,
    )
