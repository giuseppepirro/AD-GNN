"""Batched multi-task trainer for AD-GNN using block-diagonal graph batching."""

from typing import Dict, List, Tuple

import torch
import torch.nn as nn
from torch_geometric.data import Batch, HeteroData


class MultiTaskBatchTrainer:
    """
    Train AD-GNN on a meta-batch of tasks by batching graphs into a block-diagonal
    HeteroData and computing per-task loss in one update step.
    """

    def __init__(
        self,
        model: nn.Module,
        device: str = "cpu",
        learning_rate: float = 0.001,
        pos_weight: float | None = None,
        disentangle_clamp: float = 0.1,
    ) -> None:
        self.model = model.to(device)
        self.device = device
        self.optimizer = torch.optim.Adam(self.model.parameters(), lr=learning_rate)
        self.pos_weight = pos_weight
        self.disentangle_clamp = float(disentangle_clamp)

    def _bce_loss(self, predictions: torch.Tensor, labels: torch.Tensor) -> torch.Tensor:
        if self.pos_weight is None:
            return nn.BCELoss(reduction="none")(predictions, labels)
        weights = torch.ones_like(labels)
        pos_w = torch.tensor(self.pos_weight, device=labels.device, dtype=labels.dtype)
        weights = torch.where(labels == 1, pos_w, weights)
        return nn.BCELoss(weight=weights, reduction="none")(predictions, labels)

    def _remap_groups(
        self,
        task_groups: List[List[List[int]]],
        task_labels: List[List[int]],
        offsets: List[int],
        device: str,
    ) -> Tuple[List[List[int]], torch.Tensor, torch.Tensor]:
        all_groups: List[List[int]] = []
        all_labels: List[float] = []
        task_ids: List[int] = []

        for task_id, (groups, labels) in enumerate(zip(task_groups, task_labels)):
            offset = offsets[task_id]
            for g, y in zip(groups, labels):
                all_groups.append([idx + offset for idx in g])
                all_labels.append(float(y))
                task_ids.append(task_id)

        labels_t = torch.tensor(all_labels, dtype=torch.float, device=device)
        task_ids_t = torch.tensor(task_ids, dtype=torch.long, device=device)
        return all_groups, labels_t, task_ids_t

    def train_meta_batch(
        self,
        task_batch: List[Dict],
    ) -> Dict[str, float]:
        """
        task_batch items must include:
          - data: HeteroData
          - train_groups: List[List[int]]
          - train_labels: List[int]
        """
        if not task_batch:
            return {"loss": 0.0}

        self.model.train()

        data_list: List[HeteroData] = [t["data"] for t in task_batch]
        batch: HeteroData = Batch.from_data_list(data_list).to(self.device)

        offsets = batch["user"].ptr[:-1].tolist()
        task_groups = [t["train_groups"] for t in task_batch]
        task_labels = [t["train_labels"] for t in task_batch]

        groups, labels_t, task_ids_t = self._remap_groups(
            task_groups, task_labels, offsets, self.device
        )

        if len(groups) == 0:
            return {"loss": 0.0}

        preds, disentangle_loss = self.model(batch, groups, labels_t)
        loss_per_group = self._bce_loss(preds, labels_t)
        cls_loss_mean = loss_per_group.mean()

        # Per-task mean loss
        total = 0.0
        for task_id in range(len(task_batch)):
            mask = task_ids_t == task_id
            if mask.any():
                total = total + loss_per_group[mask].mean()
        per_task_mean = total / max(len(task_batch), 1)
        disentangle_clamped = torch.clamp(
            disentangle_loss, min=-self.disentangle_clamp, max=self.disentangle_clamp
        )
        loss = per_task_mean + disentangle_clamped

        self.optimizer.zero_grad()
        loss.backward()
        self.optimizer.step()

        return {
            "loss": float(loss.detach().cpu().item()),
            "cls_loss": float(cls_loss_mean.detach().cpu().item()),
            "disentangle_loss": float(disentangle_loss.detach().cpu().item()),
            "disentangle_clamped": float(disentangle_clamped.detach().cpu().item()),
        }
