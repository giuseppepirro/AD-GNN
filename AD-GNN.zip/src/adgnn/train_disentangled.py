"""Training loop for AD-GNN (Adversarial Disentangled GNN)."""

from pathlib import Path
from typing import Any, Dict, Optional, Union

import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from torch_geometric.data import HeteroData
from tqdm import tqdm

from .data import GroupDataset, collate_groups
from .model_disentangled import DisentangledDeceptionDetector


class DisentangledTrainer:
    """
    Trainer for AD-GNN with adversarial disentanglement loss.
    """

    def __init__(
        self,
        model: DisentangledDeceptionDetector,
        data: HeteroData,
        device: str = "cpu",
        learning_rate: float = 0.001,
        pos_weight: Optional[float] = None,
    ):
        """
        Initialize trainer.

        Parameters
        ----------
        model : DisentangledDeceptionDetector
            Model to train.
        data : HeteroData
            Graph data.
        device : str
            Device to use.
        learning_rate : float
            Learning rate.
        """
        self.model = model.to(device)
        self.data = data.to(device)
        self.device = device

        self.optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate)
        self.pos_weight = pos_weight

    def _bce_loss(self, predictions: torch.Tensor, labels: torch.Tensor) -> torch.Tensor:
        """Weighted BCE for probabilistic outputs."""
        if self.pos_weight is None:
            return nn.BCELoss()(predictions, labels)

        weights = torch.ones_like(labels)
        pos_w = torch.tensor(self.pos_weight, device=labels.device, dtype=labels.dtype)
        weights = torch.where(labels == 1, pos_w, weights)
        return nn.BCELoss(weight=weights)(predictions, labels)

    def train_epoch(self, train_loader: DataLoader) -> float:
        """
        Train for one epoch.

        Parameters
        ----------
        train_loader : DataLoader
            Training data loader.

        Returns
        -------
        float
            Average loss.
        """
        self.model.train()
        total_loss = 0.0
        num_batches = 0

        for groups, labels in train_loader:
            labels = labels.to(self.device)

            # Forward - returns (predictions, disentangle_loss)
            predictions, disentangle_loss = self.model(self.data, groups, labels)

            # Classification loss
            cls_loss = self._bce_loss(predictions, labels)

            # Total loss = classification + disentanglement
            loss = cls_loss + disentangle_loss

            # Backward
            self.optimizer.zero_grad()
            loss.backward()
            self.optimizer.step()

            total_loss += loss.item()
            num_batches += 1

        return total_loss / max(num_batches, 1)

    @torch.no_grad()
    def evaluate(self, val_loader: DataLoader) -> Dict[str, float]:
        """
        Evaluate on validation set.

        Parameters
        ----------
        val_loader : DataLoader
            Validation data loader.

        Returns
        -------
        Dict[str, float]
            Metrics: loss, accuracy, auprc, auroc.
        """
        self.model.eval()
        total_loss = 0.0
        num_batches = 0

        all_preds = []
        all_labels = []

        for groups, labels in val_loader:
            labels = labels.to(self.device)

            # Forward - returns (predictions, disentangle_loss)
            predictions, disentangle_loss = self.model(self.data, groups, labels)

            # Classification loss
            cls_loss = self._bce_loss(predictions, labels)

            # Total loss
            loss = cls_loss + disentangle_loss

            total_loss += loss.item()
            num_batches += 1

            # Collect predictions (already probabilities from sigmoid)
            all_preds.append(predictions.cpu().numpy())
            all_labels.append(labels.cpu().numpy())

        avg_loss = total_loss / max(num_batches, 1)

        # Compute metrics
        all_preds = np.concatenate(all_preds)
        all_labels = np.concatenate(all_labels)

        from sklearn.metrics import accuracy_score, average_precision_score, roc_auc_score

        binary_preds = (all_preds >= 0.5).astype(int)
        accuracy = accuracy_score(all_labels, binary_preds)

        # Handle case where all labels are same class
        try:
            auprc = average_precision_score(all_labels, all_preds)
        except ValueError:
            auprc = 0.0

        try:
            auroc = roc_auc_score(all_labels, all_preds)
        except ValueError:
            auroc = 0.5

        return {
            "loss": avg_loss,
            "accuracy": accuracy,
            "auprc": auprc,
            "auroc": auroc,
        }
