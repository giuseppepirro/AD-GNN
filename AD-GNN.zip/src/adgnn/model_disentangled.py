"""
Adversarial Disentangled GNN for Deception Detection

Novel contribution: Adversarial disentanglement mechanism that explicitly
models the asymmetry between coordination and communication patterns.

Key innovation: Sockpuppets exhibit HIGH coordination but LOW communication,
while legitimate users show SIMILAR patterns in both graphs. We learn
separate representations and use adversarial loss to enforce this asymmetry.
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch_geometric.nn import RGCNConv, GCNConv


class DisentangledDeceptionDetector(nn.Module):
    """
    Adversarial Disentangled GNN for detecting coordinated deception.

    Architecture:
    1. Separate encoders for coordination and communication graphs
    2. Disentanglement loss encourages different patterns for sockpuppets
    3. DeepSets pooling for group-level classification

    Novel contribution:
    - First application of adversarial disentanglement to fraud detection
    - Theoretically motivated by coordination-communication paradox
    - General framework applicable to any asymmetric fraud problem
    """

    def __init__(
        self,
        in_channels,
        hidden_channels=192,
        num_layers=5,
        dropout=0.35,
        disentangle_weight=0.1
    ):
        super().__init__()

        self.in_channels = in_channels
        self.hidden_channels = hidden_channels
        self.num_layers = num_layers
        self.dropout = dropout
        self.disentangle_weight = disentangle_weight

        # Coordination graph encoder
        self.coord_convs = nn.ModuleList()
        self.coord_convs.append(GCNConv(in_channels, hidden_channels))
        for _ in range(num_layers - 1):
            self.coord_convs.append(GCNConv(hidden_channels, hidden_channels))

        # Communication graph encoder
        self.comm_convs = nn.ModuleList()
        self.comm_convs.append(GCNConv(in_channels, hidden_channels))
        for _ in range(num_layers - 1):
            self.comm_convs.append(GCNConv(hidden_channels, hidden_channels))

        # Batch normalization for stability
        self.coord_bns = nn.ModuleList([
            nn.BatchNorm1d(hidden_channels) for _ in range(num_layers)
        ])
        self.comm_bns = nn.ModuleList([
            nn.BatchNorm1d(hidden_channels) for _ in range(num_layers)
        ])

        # DeepSets pooling (operates on concatenated embeddings)
        combined_dim = hidden_channels * 2
        self.phi = nn.Sequential(
            nn.Linear(combined_dim, combined_dim),
            nn.ReLU(),
            nn.Dropout(dropout)
        )

        self.rho = nn.Sequential(
            nn.Linear(combined_dim, combined_dim // 2),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(combined_dim // 2, 1),
            nn.Sigmoid()
        )

    def encode_graph(self, x, edge_index, convs, bns):
        """Encode a single graph type."""
        h = x
        for i, (conv, bn) in enumerate(zip(convs, bns)):
            h = conv(h, edge_index)
            h = bn(h)
            h = F.relu(h)
            if i < len(convs) - 1:
                h = F.dropout(h, p=self.dropout, training=self.training)
        return h

    def forward(self, data, groups, group_labels=None):
        """
        Forward pass with adversarial disentanglement.

        Args:
            data: HeteroData object with user features and edge indices
            groups: List of lists, each containing user indices for a group
            group_labels: Optional tensor of labels for disentanglement loss

        Returns:
            predictions: Group-level predictions
            disentangle_loss: Adversarial disentanglement loss (if training)
        """
        # Extract features and edge indices from HeteroData
        x = data["user"].x
        coord_edge_index = data["user", "coord", "user"].edge_index
        comm_edge_index = data["user", "comm", "user"].edge_index

        # Separate encoding for each graph type
        h_coord = self.encode_graph(
            x,
            coord_edge_index,
            self.coord_convs,
            self.coord_bns
        )

        h_comm = self.encode_graph(
            x,
            comm_edge_index,
            self.comm_convs,
            self.comm_bns
        )

        # Compute disentanglement loss if training
        disentangle_loss = torch.tensor(0.0, device=x.device)
        if self.training and group_labels is not None:
            disentangle_loss = self.compute_disentanglement_loss(
                h_coord, h_comm, groups, group_labels
            )

        # Concatenate for classification
        h_combined = torch.cat([h_coord, h_comm], dim=-1)

        # Group-level classification via DeepSets
        predictions = []
        for group in groups:
            group_embeddings = h_combined[group]  # [group_size, 2*hidden]
            transformed = self.phi(group_embeddings)  # [group_size, 2*hidden]
            pooled = transformed.sum(dim=0)  # [2*hidden]
            pred = self.rho(pooled)  # [1]
            predictions.append(pred)

        if len(predictions) == 1:
            predictions = predictions[0]  # Single group: [1]
        else:
            predictions = torch.stack(predictions).squeeze(-1)  # Multiple groups: [batch_size]

        return predictions, disentangle_loss

    def compute_disentanglement_loss(self, h_coord, h_comm, groups, labels):
        """
        Adversarial disentanglement loss.

        Key idea:
        - Sockpuppets (label=1): Maximize ||h_coord - h_comm||²
          (coordination and communication embeddings should be DIFFERENT)
        - Legitimate (label=0): Minimize ||h_coord - h_comm||²
          (coordination and communication embeddings should be SIMILAR)

        This enforces the coordination-communication paradox:
        sockpuppets have asymmetric patterns, legitimate users don't.
        """
        loss = 0.0
        count = 0

        for group, label in zip(groups, labels):
            # Compute embedding difference for this group
            coord_emb = h_coord[group].mean(dim=0)  # [hidden]
            comm_emb = h_comm[group].mean(dim=0)  # [hidden]

            diff = (coord_emb - comm_emb).pow(2).sum()

            if label == 1:
                # Sockpuppet: maximize difference (negate for gradient descent)
                loss -= diff
            else:
                # Legitimate: minimize difference
                loss += diff

            count += 1

        if count > 0:
            loss = loss / count

        return self.disentangle_weight * loss


class DisentangledDeceptionDetectorV2(nn.Module):
    """
    Version 2: With cross-graph attention mechanism.

    Additional innovation: Cross-attention between coordination and
    communication graphs to capture interaction patterns.
    """

    def __init__(
        self,
        in_channels,
        hidden_channels=192,
        num_layers=5,
        dropout=0.35,
        disentangle_weight=0.1,
        use_attention=True
    ):
        super().__init__()

        self.in_channels = in_channels
        self.hidden_channels = hidden_channels
        self.num_layers = num_layers
        self.dropout = dropout
        self.disentangle_weight = disentangle_weight
        self.use_attention = use_attention

        # Encoders (same as V1)
        self.coord_convs = nn.ModuleList()
        self.coord_convs.append(GCNConv(in_channels, hidden_channels))
        for _ in range(num_layers - 1):
            self.coord_convs.append(GCNConv(hidden_channels, hidden_channels))

        self.comm_convs = nn.ModuleList()
        self.comm_convs.append(GCNConv(in_channels, hidden_channels))
        for _ in range(num_layers - 1):
            self.comm_convs.append(GCNConv(hidden_channels, hidden_channels))

        self.coord_bns = nn.ModuleList([
            nn.BatchNorm1d(hidden_channels) for _ in range(num_layers)
        ])
        self.comm_bns = nn.ModuleList([
            nn.BatchNorm1d(hidden_channels) for _ in range(num_layers)
        ])

        # Cross-graph attention (INNOVATION)
        if use_attention:
            self.cross_attn_coord2comm = nn.MultiheadAttention(
                hidden_channels, num_heads=4, dropout=dropout, batch_first=True
            )
            self.cross_attn_comm2coord = nn.MultiheadAttention(
                hidden_channels, num_heads=4, dropout=dropout, batch_first=True
            )

        # DeepSets pooling
        if use_attention:
            combined_dim = hidden_channels * 4  # coord + comm + 2 attentions
        else:
            combined_dim = hidden_channels * 2

        self.phi = nn.Sequential(
            nn.Linear(combined_dim, combined_dim),
            nn.ReLU(),
            nn.Dropout(dropout)
        )

        self.rho = nn.Sequential(
            nn.Linear(combined_dim, combined_dim // 2),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(combined_dim // 2, 1),
            nn.Sigmoid()
        )

    def encode_graph(self, x, edge_index, convs, bns):
        """Encode a single graph type."""
        h = x
        for i, (conv, bn) in enumerate(zip(convs, bns)):
            h = conv(h, edge_index)
            h = bn(h)
            h = F.relu(h)
            if i < len(convs) - 1:
                h = F.dropout(h, p=self.dropout, training=self.training)
        return h

    def forward(self, data, groups, group_labels=None):
        """Forward pass with cross-attention."""
        # Encode graphs
        h_coord = self.encode_graph(
            data.x,
            data.edge_index[:, data.edge_type == 0],
            self.coord_convs,
            self.coord_bns
        )

        h_comm = self.encode_graph(
            data.x,
            data.edge_index[:, data.edge_type == 1],
            self.comm_convs,
            self.comm_bns
        )

        # Cross-graph attention (INNOVATION)
        if self.use_attention:
            # Reshape for attention: [1, N, hidden]
            h_coord_unsq = h_coord.unsqueeze(0)
            h_comm_unsq = h_comm.unsqueeze(0)

            # Coordination attends to communication
            attn_coord2comm, _ = self.cross_attn_coord2comm(
                h_coord_unsq, h_comm_unsq, h_comm_unsq
            )
            attn_coord2comm = attn_coord2comm.squeeze(0)

            # Communication attends to coordination
            attn_comm2coord, _ = self.cross_attn_comm2coord(
                h_comm_unsq, h_coord_unsq, h_coord_unsq
            )
            attn_comm2coord = attn_comm2coord.squeeze(0)

            # Concatenate all representations
            h_combined = torch.cat([
                h_coord, h_comm,
                attn_coord2comm, attn_comm2coord
            ], dim=-1)
        else:
            h_combined = torch.cat([h_coord, h_comm], dim=-1)

        # Disentanglement loss
        disentangle_loss = torch.tensor(0.0, device=data.x.device)
        if self.training and group_labels is not None:
            disentangle_loss = self.compute_disentanglement_loss(
                h_coord, h_comm, groups, group_labels
            )

        # Group classification
        predictions = []
        for group in groups:
            group_embeddings = h_combined[group]
            transformed = self.phi(group_embeddings)
            pooled = transformed.sum(dim=0)
            pred = self.rho(pooled)
            predictions.append(pred)

        predictions = torch.stack(predictions).squeeze()

        return predictions, disentangle_loss

    def compute_disentanglement_loss(self, h_coord, h_comm, groups, labels):
        """Same as V1."""
        loss = 0.0
        count = 0

        for group, label in zip(groups, labels):
            coord_emb = h_coord[group].mean(dim=0)
            comm_emb = h_comm[group].mean(dim=0)
            diff = (coord_emb - comm_emb).pow(2).sum()

            if label == 1:
                loss -= diff  # Maximize difference for sockpuppets
            else:
                loss += diff  # Minimize difference for legitimate

            count += 1

        if count > 0:
            loss = loss / count

        return self.disentangle_weight * loss


if __name__ == '__main__':
    print("Adversarial Disentangled GNN for Deception Detection")
    print("="*70)
    print("\nNovel Technical Contribution:")
    print("1. Separate encoders for coordination and communication graphs")
    print("2. Adversarial disentanglement loss enforcing asymmetry")
    print("3. Cross-graph attention (V2) for interaction modeling")
    print("\nTheoretical motivation:")
    print("- Sockpuppets: HIGH coordination, LOW communication → DIFFERENT embeddings")
    print("- Legitimate: SIMILAR coordination and communication → SIMILAR embeddings")
    print("\nThis is NOVEL - no prior work on adversarial disentanglement for")
    print("heterogeneous fraud detection with asymmetric graph patterns.")
    print("="*70)

    # Example usage
    model = DisentangledDeceptionDetector(
        in_channels=2,
        hidden_channels=192,
        num_layers=5,
        dropout=0.35,
        disentangle_weight=0.1
    )

    print(f"\nModel parameters: {sum(p.numel() for p in model.parameters()):,}")
    print("\nReady for training!")
