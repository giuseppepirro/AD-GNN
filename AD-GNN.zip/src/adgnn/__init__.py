"""AD-GNN modules for the release bundle."""
