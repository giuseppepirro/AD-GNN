"""PyTorch Geometric data preparation for Path B."""

from typing import Dict, List, Set, Tuple

import numpy as np
import pandas as pd
import torch
from torch_geometric.data import HeteroData
from torch.utils.data import Dataset


def build_hetero_graph(
    comm_edges: pd.DataFrame,
    coord_edges: pd.DataFrame,
    user_features: Dict[str, np.ndarray],
) -> Tuple[HeteroData, List[str]]:
    """
    Build PyTorch Geometric HeteroData from graphs and features.

    Parameters
    ----------
    comm_edges : pd.DataFrame
        Community graph edge list.
    coord_edges : pd.DataFrame
        Coordination graph edge list.
    user_features : Dict[str, np.ndarray]
        User feature vectors.

    Returns
    -------
    data : HeteroData
        Heterogeneous graph data.
    users : List[str]
        Ordered list of user IDs.
    """
    # Get all users
    users_set = set(user_features.keys())

    if not comm_edges.empty:
        users_set.update(comm_edges["source"])
        users_set.update(comm_edges["target"])

    if not coord_edges.empty:
        users_set.update(coord_edges["source"])
        users_set.update(coord_edges["target"])

    # Convert all users to strings to avoid sorting mixed types
    users = sorted(list(users_set), key=str)
    user_to_idx = {u: i for i, u in enumerate(users)}

    # Build feature matrix
    feat_dim = len(next(iter(user_features.values()))) if user_features else 0
    x = np.zeros((len(users), feat_dim), dtype=np.float32)

    for i, user in enumerate(users):
        if user in user_features:
            x[i] = user_features[user]

    # Create HeteroData
    data = HeteroData()

    # Node features
    data["user"].x = torch.tensor(x, dtype=torch.float)
    data["user"].num_nodes = len(users)

    # Community edges
    if not comm_edges.empty:
        comm_src = [user_to_idx[u] for u in comm_edges["source"]]
        comm_dst = [user_to_idx[u] for u in comm_edges["target"]]
        comm_edge_index = torch.tensor([comm_src, comm_dst], dtype=torch.long)
        comm_edge_weight = torch.tensor(comm_edges["weight"].values, dtype=torch.float)

        # Make undirected by adding reverse edges
        comm_edge_index = torch.cat([comm_edge_index, comm_edge_index.flip(0)], dim=1)
        comm_edge_weight = torch.cat([comm_edge_weight, comm_edge_weight], dim=0)

        data["user", "comm", "user"].edge_index = comm_edge_index
        data["user", "comm", "user"].edge_weight = comm_edge_weight
    else:
        # Empty edge index
        data["user", "comm", "user"].edge_index = torch.zeros((2, 0), dtype=torch.long)
        data["user", "comm", "user"].edge_weight = torch.zeros(0, dtype=torch.float)

    # Coordination edges
    if not coord_edges.empty:
        coord_src = [user_to_idx[u] for u in coord_edges["source"]]
        coord_dst = [user_to_idx[u] for u in coord_edges["target"]]
        coord_edge_index = torch.tensor([coord_src, coord_dst], dtype=torch.long)
        coord_edge_weight = torch.tensor(coord_edges["weight"].values, dtype=torch.float)

        # Make undirected
        coord_edge_index = torch.cat([coord_edge_index, coord_edge_index.flip(0)], dim=1)
        coord_edge_weight = torch.cat([coord_edge_weight, coord_edge_weight], dim=0)

        data["user", "coord", "user"].edge_index = coord_edge_index
        data["user", "coord", "user"].edge_weight = coord_edge_weight
    else:
        data["user", "coord", "user"].edge_index = torch.zeros((2, 0), dtype=torch.long)
        data["user", "coord", "user"].edge_weight = torch.zeros(0, dtype=torch.float)

    return data, users


class GroupDataset(Dataset):
    """
    Dataset of groups for binary classification.

    Each sample is a group (set of user indices) with a label.
    """

    def __init__(
        self,
        groups: List[Set[int]],
        labels: List[int],
    ):
        """
        Initialize dataset.

        Parameters
        ----------
        groups : List[Set[int]]
            List of groups (sets of user node indices).
        labels : List[int]
            Binary labels (0 or 1).
        """
        assert len(groups) == len(labels)
        self.groups = groups
        self.labels = labels

    def __len__(self) -> int:
        return len(self.groups)

    def __getitem__(self, idx: int) -> Tuple[Set[int], int]:
        return self.groups[idx], self.labels[idx]


def collate_groups(
    batch: List[Tuple[Set[int], int]]
) -> Tuple[List[Set[int]], torch.Tensor]:
    """
    Collate function for GroupDataset.

    Parameters
    ----------
    batch : List[Tuple[Set[int], int]]
        List of (group, label) tuples.

    Returns
    -------
    groups : List[Set[int]]
        Batch of groups.
    labels : torch.Tensor
        Batch of labels.
    """
    groups = [item[0] for item in batch]
    labels = torch.tensor([item[1] for item in batch], dtype=torch.float)
    return groups, labels


def sample_negative_groups(
    positive_groups: List[Set[str]],
    all_users: List[str],
    ratio: float = 1.0,
    match_size: bool = True,
    match_activity: bool = False,
    user_activity: Dict[str, int] = None,
    random_seed: int = 42,
) -> List[Set[str]]:
    """
    Sample negative groups for training.

    Parameters
    ----------
    positive_groups : List[Set[str]]
        Positive (deceptive) groups.
    all_users : List[str]
        All user IDs in the window.
    ratio : float
        Number of negatives per positive.
    match_size : bool
        Match size distribution of positives.
    match_activity : bool
        Sample users with similar activity levels.
    user_activity : Dict[str, int], optional
        User activity counts (for matching).
    random_seed : int
        Random seed.

    Returns
    -------
    List[Set[str]]
        Negative groups.
    """
    rng = np.random.RandomState(random_seed)

    num_negatives = int(len(positive_groups) * ratio)
    negative_groups = []

    # Get size distribution
    if match_size:
        sizes = [len(g) for g in positive_groups]
    else:
        sizes = [rng.randint(3, 10) for _ in range(num_negatives)]

    # Sample negative groups
    for i in range(num_negatives):
        size = sizes[i % len(sizes)] if match_size else sizes[i]

        # Sample users
        if match_activity and user_activity:
            # Sample with replacement weighted by activity
            activities = np.array([user_activity.get(u, 1) for u in all_users])
            probs = activities / activities.sum()
            sampled = rng.choice(all_users, size=size, replace=False, p=probs)
        else:
            sampled = rng.choice(all_users, size=size, replace=False)

        negative_groups.append(set(sampled))

    return negative_groups


def prepare_training_data(
    positive_groups: List[Set[str]],
    all_users: List[str],
    user_to_idx: Dict[str, int],
    negative_ratio: float = 1.0,
    match_size: bool = True,
    match_activity: bool = False,
    user_activity: Dict[str, int] = None,
    val_split: float = 0.15,
    test_split: float = 0.15,
    random_seed: int = 42,
) -> Tuple[GroupDataset, GroupDataset, GroupDataset]:
    """
    Prepare train/val/test datasets.

    Parameters
    ----------
    positive_groups : List[Set[str]]
        Positive groups (user ID sets).
    all_users : List[str]
        All user IDs.
    user_to_idx : Dict[str, int]
        Mapping from user_id to node index.
    negative_ratio : float
        Negatives per positive.
    match_size : bool
        Match size distribution.
    match_activity : bool
        Match activity distribution.
    user_activity : Dict[str, int], optional
        User activity counts.
    val_split : float
        Validation split fraction.
    test_split : float
        Test split fraction.
    random_seed : int
        Random seed.

    Returns
    -------
    train_dataset : GroupDataset
    val_dataset : GroupDataset
    test_dataset : GroupDataset
    """
    rng = np.random.RandomState(random_seed)

    # Sample negatives
    negative_groups = sample_negative_groups(
        positive_groups,
        all_users,
        ratio=negative_ratio,
        match_size=match_size,
        match_activity=match_activity,
        user_activity=user_activity,
        random_seed=random_seed,
    )

    # Convert to node indices
    positive_idx_groups = [
        {user_to_idx[u] for u in g if u in user_to_idx} for g in positive_groups
    ]
    negative_idx_groups = [
        {user_to_idx[u] for u in g if u in user_to_idx} for g in negative_groups
    ]

    # Create labels
    positive_labels = [1] * len(positive_idx_groups)
    negative_labels = [0] * len(negative_idx_groups)

    # Combine and shuffle
    all_groups = positive_idx_groups + negative_idx_groups
    all_labels = positive_labels + negative_labels

    indices = np.arange(len(all_groups))
    rng.shuffle(indices)

    all_groups = [all_groups[i] for i in indices]
    all_labels = [all_labels[i] for i in indices]

    # Split
    n = len(all_groups)
    n_test = int(n * test_split)
    n_val = int(n * val_split)
    n_train = n - n_test - n_val

    train_groups = all_groups[:n_train]
    train_labels = all_labels[:n_train]

    val_groups = all_groups[n_train:n_train + n_val]
    val_labels = all_labels[n_train:n_train + n_val]

    test_groups = all_groups[n_train + n_val:]
    test_labels = all_labels[n_train + n_val:]

    # Create datasets
    train_dataset = GroupDataset(train_groups, train_labels)
    val_dataset = GroupDataset(val_groups, val_labels)
    test_dataset = GroupDataset(test_groups, test_labels)

    return train_dataset, val_dataset, test_dataset
