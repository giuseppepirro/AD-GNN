"""Time window slicing utilities."""

from datetime import timedelta
from pathlib import Path
from typing import Dict, Iterator, List, Tuple, Union

import pandas as pd


class WindowSlicer:
    """
    Slice activity log into time windows.

    Parameters
    ----------
    window_size_days : int
        Size of each window in days.
    step_days : int
        Step size between windows in days.
    min_user_activity : int
        Minimum number of events per user to include in window.
    """

    def __init__(
        self,
        window_size_days: int = 14,
        step_days: int = 7,
        min_user_activity: int = 5,
    ):
        self.window_size_days = window_size_days
        self.step_days = step_days
        self.min_user_activity = min_user_activity

    def slice(self, df: pd.DataFrame) -> Iterator[Tuple[int, pd.Timestamp, pd.Timestamp, pd.DataFrame]]:
        """
        Slice activity log into time windows.

        Parameters
        ----------
        df : pd.DataFrame
            Activity log with columns (user_id, page_id, timestamp).

        Yields
        ------
        window_id : int
            Window identifier (0-indexed).
        start : pd.Timestamp
            Window start time (inclusive).
        end : pd.Timestamp
            Window end time (exclusive).
        window_df : pd.DataFrame
            Events in this window.
        """
        if df.empty:
            return

        min_time = df["timestamp"].min()
        max_time = df["timestamp"].max()

        window_delta = timedelta(days=self.window_size_days)
        step_delta = timedelta(days=self.step_days)

        window_id = 0
        start = min_time

        while start < max_time:
            end = start + window_delta

            # Filter events in window
            mask = (df["timestamp"] >= start) & (df["timestamp"] < end)
            window_df = df[mask].copy()

            # Filter by minimum user activity
            if self.min_user_activity > 0:
                user_counts = window_df["user_id"].value_counts()
                active_users = user_counts[user_counts >= self.min_user_activity].index
                window_df = window_df[window_df["user_id"].isin(active_users)]

            if not window_df.empty:
                yield window_id, start, end, window_df

            window_id += 1
            start += step_delta

    def slice_and_save(
        self, df: pd.DataFrame, output_dir: Union[str, Path]
    ) -> List[Dict[str, Union[int, str]]]:
        """
        Slice activity log and save windows to disk.

        Parameters
        ----------
        df : pd.DataFrame
            Activity log.
        output_dir : str or Path
            Directory to save window files.

        Returns
        -------
        List[Dict]
            Window metadata with keys: window_id, start, end, path, num_events, num_users, num_pages.
        """
        output_dir = Path(output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)

        metadata = []

        for window_id, start, end, window_df in self.slice(df):
            # Save window data
            window_path = output_dir / f"window_{window_id:04d}.parquet"
            window_df.to_parquet(window_path, index=False)

            # Collect metadata
            metadata.append({
                "window_id": window_id,
                "start": start.isoformat(),
                "end": end.isoformat(),
                "path": str(window_path),
                "num_events": len(window_df),
                "num_users": window_df["user_id"].nunique(),
                "num_pages": window_df["page_id"].nunique(),
            })

        # Save metadata
        metadata_df = pd.DataFrame(metadata)
        metadata_path = output_dir / "windows_metadata.csv"
        metadata_df.to_csv(metadata_path, index=False)

        return metadata


def load_window(window_path: Union[str, Path]) -> pd.DataFrame:
    """
    Load a single window from disk.

    Parameters
    ----------
    window_path : str or Path
        Path to window parquet file.

    Returns
    -------
    pd.DataFrame
        Window data.
    """
    return pd.read_parquet(window_path)


def load_windows_metadata(windows_dir: Union[str, Path]) -> pd.DataFrame:
    """
    Load windows metadata.

    Parameters
    ----------
    windows_dir : str or Path
        Directory containing windows.

    Returns
    -------
    pd.DataFrame
        Windows metadata.
    """
    metadata_path = Path(windows_dir) / "windows_metadata.csv"
    return pd.read_csv(metadata_path)
