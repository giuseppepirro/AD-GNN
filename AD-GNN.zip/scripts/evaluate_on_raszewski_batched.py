#!/usr/bin/env python3
"""
Batched multi-task training on Raszewski dataset.

This script trains a shared AD-GNN model on meta-batches of investigations by
packing their graphs into a block-diagonal HeteroData batch and computing
per-task loss in one update step.
"""

import argparse
import json
from pathlib import Path
from typing import Dict, List, Tuple

import numpy as np
import pandas as pd
import torch
from sklearn.metrics import average_precision_score, roc_auc_score
from tqdm import tqdm

import sys
sys.path.insert(0, str(Path(__file__).parent.parent / 'src'))

from community_deception.adgnn.data import build_hetero_graph
from community_deception.adgnn.model_disentangled import DisentangledDeceptionDetector
from community_deception.adgnn.train_multitask import MultiTaskBatchTrainer
from community_deception.raszewski_cache import build_or_load_raszewski_payload

RASZEWSKI_DATA = Path('data/raszewski_dataset/data')
STATS_FILE = Path('data/raszewski_dataset/stats.csv')

FEATURE_NAMES = [
    "edit_count",
    "unique_pages",
    "pages_per_day",
    "temporal_spread",
    "activity_concentration",
]


def parse_args():
    parser = argparse.ArgumentParser(description="Batched multi-task training on Raszewski")
    parser.add_argument("--output", type=str, default="results/raszewski/adgnn_eval_batched")
    parser.add_argument("--device", type=str, default="cpu")
    parser.add_argument("--sample-size", type=int, default=1000)
    parser.add_argument("--full", action="store_true")
    parser.add_argument("--coord-method", type=str, default="sparse", choices=["sparse", "exact"])
    parser.add_argument("--coord-bucket-seconds", type=int, default=3600)
    parser.add_argument("--meta-batch-size", type=int, default=8)
    parser.add_argument("--epochs", type=int, default=5)
    parser.add_argument("--neg-ratio", type=float, default=2.0)
    parser.add_argument("--group-size", type=int, default=3)
    parser.add_argument("--test-groups-per-user", type=int, default=3)
    parser.add_argument("--infer-batch-size", type=int, default=256)
    parser.add_argument("--disentangle-weight", type=float, default=0.01)
    parser.add_argument("--disentangle-clamp", type=float, default=0.1)
    parser.add_argument("--cache-dir", type=str, default=None)
    parser.add_argument("--max-users", type=int, default=None,
                        help="Skip investigations with more than this many users (approx = positives+negatives).")
    parser.add_argument("--sort-by-size", action="store_true",
                        help="Process smaller investigations first for lower memory use.")
    parser.add_argument("--num-shards", type=int, default=1)
    parser.add_argument("--shard-id", type=int, default=0)
    return parser.parse_args()

def build_task(payload: Dict, neg_ratio: float, group_size: int) -> Dict | None:
    comm_edges = payload["comm_edges"]
    coord_edges = payload["coord_edges"]
    user_features = payload["user_features"]
    user_meta = payload["user_meta"]

    data, user_list = build_hetero_graph(comm_edges, coord_edges, user_features)
    user_to_idx = {u: i for i, u in enumerate(user_list)}

    sock_users = [u for u, m in user_meta.items() if m["sock"] == 1]
    neg_users = [u for u, m in user_meta.items() if m["sock"] == 0]
    if not sock_users or not neg_users:
        return None

    puppetmaster = max(sock_users, key=lambda u: user_meta[u]["count"])
    train_pos_count = user_meta[puppetmaster]["count"]
    test_pos_count = sum(user_meta[u]["count"] for u in sock_users if u != puppetmaster)
    if train_pos_count == 0 or test_pos_count == 0:
        return None

    neg_counts = {u: user_meta[u]["count"] for u in neg_users}
    total_neg_count = sum(neg_counts.values())
    train_ratio = train_pos_count / max(train_pos_count + test_pos_count, 1)
    target_train_neg = int(total_neg_count * train_ratio)

    rng = np.random.RandomState(42)
    neg_users_shuffled = list(neg_counts.keys())
    rng.shuffle(neg_users_shuffled)

    train_neg_users = []
    seen = set()
    total_seen = 0
    for u in neg_users_shuffled:
        if total_seen >= target_train_neg and len(train_neg_users) >= 2:
            break
        if u in seen:
            continue
        seen.add(u)
        train_neg_users.append(u)
        total_seen += int(neg_counts[u])

    if len(train_neg_users) < 2:
        mid = max(1, len(neg_users) // 2)
        train_neg_users = list(neg_users[:mid])

    test_neg_users = [u for u in neg_users if u not in set(train_neg_users)]
    if len(test_neg_users) < 2:
        test_neg_users = list(neg_users[-max(2, len(neg_users) // 2):])

    train_neg_idx = [user_to_idx[u] for u in train_neg_users if u in user_to_idx]
    test_neg_idx = [user_to_idx[u] for u in test_neg_users if u in user_to_idx]
    if len(train_neg_idx) < 2 or len(test_neg_idx) < 2:
        return None

    puppetmaster_idx = user_to_idx.get(puppetmaster)
    if puppetmaster_idx is None:
        return None

    pos_count = max(10, min(50, train_pos_count))
    group_size = max(2, min(group_size, len(train_neg_idx) + 1))

    train_groups = []
    train_labels = []
    for _ in range(pos_count):
        others = list(np.random.choice(train_neg_idx, size=group_size - 1, replace=False))
        train_groups.append([puppetmaster_idx] + others)
        train_labels.append(1)

    neg_count = int(len(train_groups) * neg_ratio)
    for _ in range(neg_count):
        size = max(2, min(group_size, len(train_neg_idx)))
        group = list(np.random.choice(train_neg_idx, size=size, replace=False))
        train_groups.append(group)
        train_labels.append(0)

    test_users = [
        u for u in user_meta.keys()
        if (u in sock_users and u != puppetmaster) or (u in test_neg_users)
    ]

    return {
        "data": data,
        "user_to_idx": user_to_idx,
        "user_meta": user_meta,
        "train_groups": train_groups,
        "train_labels": train_labels,
        "test_users": test_users,
        "test_neg_idx": test_neg_idx,
        "puppetmaster": puppetmaster,
    }


def evaluate_task(model, task: Dict, device: str, test_groups_per_user: int, infer_batch_size: int) -> Dict | None:
    user_to_idx = task["user_to_idx"]
    user_meta = task["user_meta"]
    test_users = task["test_users"]
    test_neg_idx = task["test_neg_idx"]

    data = task["data"].to(device)

    test_labels = []
    test_preds = []

    model.eval()
    with torch.no_grad():
        for test_user in test_users:
            if test_user not in user_to_idx:
                continue
            test_user_idx = user_to_idx[test_user]
            true_label = int(user_meta[test_user]["sock"])

            groups = []
            for _ in range(test_groups_per_user):
                group_size = max(2, min(3, len(test_neg_idx) + 1))
                neg_pool = [i for i in test_neg_idx if i != test_user_idx]
                if len(neg_pool) < group_size - 1:
                    continue
                others = list(np.random.choice(neg_pool, size=group_size - 1, replace=False))
                groups.append([test_user_idx] + others)

            if not groups:
                continue

            user_preds = []
            for i in range(0, len(groups), infer_batch_size):
                batch_groups = groups[i:i + infer_batch_size]
                probs, _ = model(data, batch_groups)
                probs = probs.detach().cpu().numpy().reshape(-1)
                user_preds.extend(probs.tolist())

            if user_preds:
                test_labels.append(true_label)
                test_preds.append(float(np.mean(user_preds)))

    if len(test_labels) < 2 or len(np.unique(test_labels)) < 2:
        return None

    auprc = average_precision_score(test_labels, test_preds)
    auroc = roc_auc_score(test_labels, test_preds)
    return {"auprc": auprc, "auroc": auroc}


def main():
    args = parse_args()
    output_dir = Path(args.output)
    output_dir.mkdir(parents=True, exist_ok=True)

    cache_dir = Path(args.cache_dir) if args.cache_dir else (output_dir / "cache")
    cache_dir.mkdir(parents=True, exist_ok=True)
    config = {
        "output": str(output_dir),
        "cache_dir": str(cache_dir),
        "device": args.device,
        "full": bool(args.full),
        "sample_size": None if args.full else int(args.sample_size),
        "coord_method": args.coord_method,
        "coord_bucket_seconds": args.coord_bucket_seconds,
        "meta_batch_size": int(args.meta_batch_size),
        "epochs": int(args.epochs),
        "neg_ratio": float(args.neg_ratio),
        "group_size": int(args.group_size),
        "test_groups_per_user": int(args.test_groups_per_user),
        "infer_batch_size": int(args.infer_batch_size),
        "disentangle_weight": float(args.disentangle_weight),
        "disentangle_clamp": float(args.disentangle_clamp),
        "max_users": args.max_users,
        "sort_by_size": bool(args.sort_by_size),
        "num_shards": int(args.num_shards),
        "shard_id": int(args.shard_id),
    }
    with open(output_dir / "config.yaml", "w") as f:
        import yaml
        yaml.safe_dump(config, f, sort_keys=False)

    stats = pd.read_csv(STATS_FILE)
    valid = stats[
        (stats['num_puppetmaster'] >= 10) &
        (stats['num_sockpuppets'] >= 5) &
        (stats['num_negatives'] / stats['num_positives'] >= 1.0)
    ]
    valid = valid.copy()
    valid["task_size"] = valid["num_positives"] + valid["num_negatives"]
    if args.max_users is not None:
        valid = valid[valid["task_size"] <= args.max_users]
    if args.sort_by_size:
        valid = valid.sort_values("task_size")

    if args.full:
        sample = valid
    else:
        sample = valid.head(args.sample_size)

    sample = sample.reset_index(drop=True)
    if args.num_shards > 1:
        if args.shard_id < 0 or args.shard_id >= args.num_shards:
            raise ValueError("Invalid shard_id")
        sample = sample[sample.index % args.num_shards == args.shard_id]

    inv_files = [RASZEWSKI_DATA / name for name in sample["name"].tolist()]

    print(f"Loading tasks list: {len(inv_files)} investigations")

    device = args.device
    if device == "cuda" and not torch.cuda.is_available():
        device = "cpu"
    if device == "mps" and not torch.backends.mps.is_available():
        device = "cpu"

    model = DisentangledDeceptionDetector(
        in_channels=5,
        hidden_channels=96,
        num_layers=4,
        dropout=0.3,
        disentangle_weight=args.disentangle_weight,
    )
    trainer = MultiTaskBatchTrainer(
        model,
        device=device,
        learning_rate=0.001,
        disentangle_clamp=float(args.disentangle_clamp),
    )

    for epoch in range(args.epochs):
        inv_list = list(inv_files)
        np.random.shuffle(inv_list)
        losses = []
        step = 0
        for i in tqdm(range(0, len(inv_list), args.meta_batch_size), desc=f"Epoch {epoch+1}"):
            batch_paths = inv_list[i:i + args.meta_batch_size]
            task_batch: List[Dict] = []
            for inv in batch_paths:
                try:
                    payload = build_or_load_raszewski_payload(
                        inv,
                        coord_method=args.coord_method,
                        coord_bucket_seconds=args.coord_bucket_seconds,
                        cache_dir=cache_dir,
                        use_cache=True,
                    )
                except Exception:
                    continue
                task = build_task(payload, args.neg_ratio, args.group_size)
                if task is None:
                    continue
                task_batch.append(task)
            if not task_batch:
                continue
            metrics = trainer.train_meta_batch(task_batch)
            losses.append(metrics["loss"])
            step += 1
            if step % 100 == 0:
                recent = losses[-100:] if len(losses) >= 100 else losses
                print(
                    f"Epoch {epoch+1} step {step}: "
                    f"mean_loss={float(np.mean(recent)):.4f} "
                    f"cls={metrics.get('cls_loss', 0.0):.4f} "
                    f"dis={metrics.get('disentangle_loss', 0.0):.4f} "
                    f"clamp={metrics.get('disentangle_clamped', 0.0):.4f}"
                )
            # Reduce memory pressure between batches
            if device == "mps":
                torch.mps.empty_cache()
        if losses:
            print(f"Epoch {epoch+1} mean loss: {float(np.mean(losses)):.4f}")

    # Evaluate
    results = []
    for inv in tqdm(inv_files, desc="Evaluating"):
        try:
            payload = build_or_load_raszewski_payload(
                inv,
                coord_method=args.coord_method,
                coord_bucket_seconds=args.coord_bucket_seconds,
                cache_dir=cache_dir,
                use_cache=True,
            )
        except Exception:
            continue
        task = build_task(payload, args.neg_ratio, args.group_size)
        if task is None:
            continue
        res = evaluate_task(model, task, device, args.test_groups_per_user, args.infer_batch_size)
        if res:
            results.append(res)
        if device == "mps":
            torch.mps.empty_cache()

    results_path = output_dir / "batched_results.json"
    with open(results_path, "w") as f:
        json.dump(results, f, indent=2)

    if results:
        mean_auprc = float(np.mean([r["auprc"] for r in results]))
        mean_auroc = float(np.mean([r["auroc"] for r in results]))
        summary = {
            "num_tasks": len(results),
            "mean_auprc": mean_auprc,
            "mean_auroc": mean_auroc,
        }
        with open(output_dir / "summary.json", "w") as f:
            json.dump(summary, f, indent=2)
        print(f"Mean AUPRC: {mean_auprc:.4f} | Mean AUROC: {mean_auroc:.4f}")


if __name__ == "__main__":
    main()
