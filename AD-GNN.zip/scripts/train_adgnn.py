#!/usr/bin/env python3
"""
Train AD-GNN (Adversarial Disentangled GNN) with configurable hyperparameters.
"""

import argparse
import json
import yaml
from pathlib import Path
import pandas as pd
import numpy as np
import torch
from torch.utils.data import DataLoader
from tqdm import tqdm
import sys

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from community_deception.adgnn.data import build_hetero_graph, GroupDataset, collate_groups
from community_deception.features import extract_user_features, normalize_features
from community_deception.graphs import build_graphs_adgnn
from community_deception.adgnn.model_disentangled import DisentangledDeceptionDetector
from community_deception.adgnn.train_disentangled import DisentangledTrainer


def load_window_data(window_path, graphs_dir, rebuild_graphs=False):
    """Load window data and corresponding graph CSVs (or rebuild)."""
    window_id = Path(window_path).stem
    window_num = window_id.replace('window_', '')

    # Load window
    window_df = pd.read_parquet(window_path)

    if rebuild_graphs:
        comm_edges, coord_edges = build_graphs_adgnn(window_df, temporal_decay=False)
        return window_df, comm_edges, coord_edges

    # Load graph CSV files
    comm_file = graphs_dir / f'comm_{window_num}.csv'
    coord_file = graphs_dir / f'coord_{window_num}.csv'

    if not comm_file.exists() and not coord_file.exists():
        comm_edges, coord_edges = build_graphs_adgnn(window_df, temporal_decay=False)
        return window_df, comm_edges, coord_edges

    # Load edge lists
    comm_edges = pd.read_csv(comm_file) if comm_file.exists() else pd.DataFrame(columns=['source', 'target', 'weight'])
    coord_edges = pd.read_csv(coord_file) if coord_file.exists() else pd.DataFrame(columns=['source', 'target', 'weight'])

    return window_df, comm_edges, coord_edges


def prepare_labels_for_window(window_df, all_labels):
    """Create labels for groups in this window."""
    active_users = set(window_df['user_id'].unique())

    # Extract positive_groups from labels dict if needed
    if isinstance(all_labels, dict) and 'positive_groups' in all_labels:
        label_groups = all_labels['positive_groups']
    else:
        label_groups = all_labels

    positive_groups = []
    for group in label_groups:
        if any(u in active_users for u in group):
            window_group = [u for u in group if u in active_users]
            if len(window_group) >= 2:
                positive_groups.append(window_group)

    return positive_groups


def train_single_window(window_path, labels, graphs_dir, output_dir, device='cpu',
                       hidden_channels=96, num_layers=4, dropout=0.3, neg_ratio=3,
                       learning_rate=0.0005, max_epochs=80, patience=8, window_num=None,
                       rebuild_graphs=False):
    """Train model on a single window with configurable hyperparameters."""

    # Check if results already exist
    if output_dir and window_num:
        result_file = Path(output_dir) / f"window_{window_num}.json"
        if result_file.exists():
            # Skip already processed window
            return None

    # Load data
    window_df, comm_edges, coord_edges = load_window_data(window_path, graphs_dir, rebuild_graphs=rebuild_graphs)
    if window_df is None:
        return None

    # Prepare labels
    positive_groups = prepare_labels_for_window(window_df, labels)
    if len(positive_groups) == 0:
        return None

    # Extract richer temporal + activity features
    feature_names = [
        'edit_count', 'unique_pages', 'pages_per_day',
        'temporal_spread', 'activity_concentration'
    ]
    user_features_dict = extract_user_features(window_df, feature_names)
    user_features_dict = normalize_features(user_features_dict)

    # Build graph
    data, users = build_hetero_graph(comm_edges, coord_edges, user_features_dict)
    user_to_idx = {u: i for i, u in enumerate(users)}

    # Create dataset
    dataset_groups = []
    dataset_labels = []

    # Positive examples
    for group in positive_groups:
        group_indices = [user_to_idx[u] for u in group if u in user_to_idx]
        if len(group_indices) >= 2:
            dataset_groups.append(group_indices)
            dataset_labels.append(1)

    # Negative examples (configurable ratio)
    np.random.seed(42)
    for _ in range(len(positive_groups) * neg_ratio):
        size = np.random.randint(2, min(8, max(3, len(users) // 2)))
        if len(users) >= size:
            neg_group = np.random.choice(len(users), size=size, replace=False).tolist()
            dataset_groups.append(neg_group)
            dataset_labels.append(0)

    if len(dataset_groups) < 8:
        return None

    # Create dataset
    dataset = GroupDataset(dataset_groups, dataset_labels)

    # Split
    n = len(dataset)
    indices = np.random.permutation(n)
    train_size = int(0.7 * n)
    val_size = int(0.15 * n)

    train_idx = indices[:train_size]
    val_idx = indices[train_size:train_size+val_size]
    test_idx = indices[train_size+val_size:]

    train_dataset = torch.utils.data.Subset(dataset, train_idx)
    val_dataset = torch.utils.data.Subset(dataset, val_idx)
    test_dataset = torch.utils.data.Subset(dataset, test_idx)

    # Create dataloaders
    batch_size = min(16, max(4, len(train_dataset) // 4))
    train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True, collate_fn=collate_groups)
    val_loader = DataLoader(val_dataset, batch_size=batch_size, shuffle=False, collate_fn=collate_groups)
    test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False, collate_fn=collate_groups)

    # Create AD-GNN model with configurable parameters
    model = DisentangledDeceptionDetector(
        in_channels=len(feature_names),
        hidden_channels=hidden_channels,
        num_layers=num_layers,
        dropout=dropout,
        disentangle_weight=0.1
    )

    # Compute class-balance weight
    pos = sum(dataset_labels)
    neg = len(dataset_labels) - pos
    pos_weight = (neg / pos) if pos > 0 else None

    # Train with DisentangledTrainer
    trainer = DisentangledTrainer(
        model,
        data,
        device=device,
        learning_rate=learning_rate,
        pos_weight=pos_weight,
    )

    best_val_auprc = 0
    best_val_acc = 0
    no_improve = 0
    best_epoch = 0

    for epoch in range(max_epochs):
        train_loss = trainer.train_epoch(train_loader)
        val_metrics = trainer.evaluate(val_loader)

        if val_metrics['auprc'] > best_val_auprc:
            best_val_auprc = val_metrics['auprc']
            best_val_acc = val_metrics['accuracy']
            best_epoch = epoch
            no_improve = 0
            if output_dir:
                Path(output_dir).mkdir(parents=True, exist_ok=True)
                # Save model checkpoint
                checkpoint = {
                    'epoch': epoch,
                    'model_state_dict': model.state_dict(),
                    'optimizer_state_dict': trainer.optimizer.state_dict(),
                    'val_auprc': best_val_auprc,
                    'val_accuracy': best_val_acc,
                    'hyperparameters': {
                        'hidden_channels': hidden_channels,
                        'num_layers': num_layers,
                        'dropout': dropout,
                        'learning_rate': learning_rate,
                        'neg_ratio': neg_ratio
                    }
                }
                torch.save(checkpoint, Path(output_dir) / 'checkpoint_best.pt')
        else:
            no_improve += 1

        if no_improve >= patience:
            break

    # Test
    test_metrics = trainer.evaluate(test_loader)

    return {
        'val_auprc': best_val_auprc,
        'val_accuracy': best_val_acc,
        'test_auprc': test_metrics.get('auprc', 0),
        'test_accuracy': test_metrics.get('accuracy', 0),
        'test_auroc': test_metrics.get('auroc', 0),
        'test_f1': test_metrics.get('f1', 0),
        'num_positive': len(positive_groups),
        'num_examples': len(dataset_groups),
        'best_epoch': best_epoch,
        'total_epochs': epoch + 1
    }


def main():
    parser = argparse.ArgumentParser(description='Train Path B with configurable hyperparameters')
    parser.add_argument('--windows', type=str, required=True)
    parser.add_argument('--labels', type=str, required=True)
    parser.add_argument('--output', type=str, required=True)
    parser.add_argument('--graphs', type=str, default=None)
    parser.add_argument('--rebuild-graphs', action='store_true')
    parser.add_argument('--max-windows', type=int, default=None)
    parser.add_argument('--device', type=str, default='mps')

    # Hyperparameters
    parser.add_argument('--hidden-channels', type=int, default=96)
    parser.add_argument('--num-layers', type=int, default=4)
    parser.add_argument('--dropout', type=float, default=0.3)
    parser.add_argument('--neg-ratio', type=int, default=3)
    parser.add_argument('--learning-rate', type=float, default=0.0005)
    parser.add_argument('--max-epochs', type=int, default=80)
    parser.add_argument('--patience', type=int, default=8)

    args = parser.parse_args()

    # Device setup
    if args.device == 'cuda' and not torch.cuda.is_available():
        print("CUDA not available, using CPU")
        args.device = 'cpu'
    elif args.device == 'mps' and not torch.backends.mps.is_available():
        print("MPS not available, using CPU")
        args.device = 'cpu'

    print(f"Using device: {args.device}")
    print(f"Hyperparameters:")
    print(f"  Hidden channels: {args.hidden_channels}")
    print(f"  Num layers: {args.num_layers}")
    print(f"  Dropout: {args.dropout}")
    print(f"  Neg ratio: {args.neg_ratio}")
    print(f"  Learning rate: {args.learning_rate}")

    # Load labels
    with open(args.labels) as f:
        labels = json.load(f)

    # Get graphs directory
    graphs_dir = Path(args.graphs) if args.graphs else Path('artifacts_wikisocks/graphs')

    # Get windows
    windows_dir = Path(args.windows)
    window_paths = sorted(windows_dir.glob('window_*.parquet'))

    if args.max_windows:
        window_paths = window_paths[:args.max_windows]

    print(f"Training on {len(window_paths)} windows")

    # Create output directory
    output_dir = Path(args.output)
    output_dir.mkdir(parents=True, exist_ok=True)

    # Save configuration
    config = {
        'device': args.device,
        'hyperparameters': {
            'hidden_channels': args.hidden_channels,
            'num_layers': args.num_layers,
            'dropout': args.dropout,
            'neg_ratio': args.neg_ratio,
            'learning_rate': args.learning_rate,
            'max_epochs': args.max_epochs,
            'patience': args.patience,
            'disentangle_weight': 0.1
        },
        'model': 'DisentangledDeceptionDetector (AD-GNN)',
        'description': 'Adversarial Disentangled GNN for sockpuppet detection'
    }

    with open(output_dir / 'config.json', 'w') as f:
        json.dump(config, f, indent=2)
    with open(output_dir / 'config.yaml', 'w') as f:
        yaml.safe_dump(config, f, sort_keys=False)

    # Train on each window
    all_results = []
    best_global_auprc = 0
    best_global_window = None

    for window_path in tqdm(window_paths, desc="Training windows"):
        window_num = window_path.stem.replace('window_', '')

        results = train_single_window(
            window_path,
            labels,
            graphs_dir,
            output_dir / f"window_{window_num}",
            device=args.device,
            hidden_channels=args.hidden_channels,
            num_layers=args.num_layers,
            dropout=args.dropout,
            neg_ratio=args.neg_ratio,
            learning_rate=args.learning_rate,
            max_epochs=args.max_epochs,
            patience=args.patience,
            window_num=window_num,
            rebuild_graphs=args.rebuild_graphs,
        )

        if results:
            results['window'] = int(window_num)
            all_results.append(results)

            # Save individual result
            result_path = output_dir / f"window_{window_num}.json"
            with open(result_path, 'w') as f:
                json.dump(results, f, indent=2)

            # Track best global model
            if results['test_auprc'] > best_global_auprc:
                best_global_auprc = results['test_auprc']
                best_global_window = window_num

    # Save summary
    if all_results:
        summary = {
            'num_windows': len(all_results),
            'test_auprc_mean': float(np.mean([r['test_auprc'] for r in all_results])),
            'test_auprc_std': float(np.std([r['test_auprc'] for r in all_results])),
            'test_accuracy_mean': float(np.mean([r['test_accuracy'] for r in all_results])),
            'test_accuracy_std': float(np.std([r['test_accuracy'] for r in all_results])),
            'best_window': best_global_window,
            'best_test_auprc': best_global_auprc,
            'config': config
        }

        with open(output_dir / 'summary.json', 'w') as f:
            json.dump(summary, f, indent=2)

        # Copy best model checkpoint to global best
        if best_global_window:
            best_checkpoint_path = output_dir / f"window_{best_global_window}" / 'checkpoint_best.pt'
            if best_checkpoint_path.exists():
                import shutil
                shutil.copy(best_checkpoint_path, output_dir / 'best_model_global.pt')
                print(f"\nBest model from window {best_global_window} saved to best_model_global.pt")

        print(f"\n{'='*60}")
        print("RESULTS")
        print(f"{'='*60}")
        print(f"Test AUPRC: {summary['test_auprc_mean']:.3f} ± {summary['test_auprc_std']:.3f}")
        print(f"Test Accuracy: {summary['test_accuracy_mean']:.3f} ± {summary['test_accuracy_std']:.3f}")
        print(f"Best window: {best_global_window} (AUPRC: {best_global_auprc:.3f})")
        print(f"Trained on {summary['num_windows']} windows")
        print(f"\nConfiguration saved to: {output_dir / 'config.json'}")
        print(f"Results saved to: {output_dir / 'summary.json'}")


if __name__ == '__main__':
    main()
