#!/usr/bin/env python3
"""Precompute cached Raszewski payloads for batched evaluation."""

import argparse
from pathlib import Path
import sys

import pandas as pd
from tqdm import tqdm

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from community_deception.raszewski_cache import build_or_load_raszewski_payload


def main() -> None:
    parser = argparse.ArgumentParser(description="Prepare cached Raszewski payloads")
    parser.add_argument("--data-dir", type=str, default="data/raszewski_dataset/data")
    parser.add_argument("--stats-file", type=str, default="data/raszewski_dataset/stats.csv")
    parser.add_argument("--cache-dir", type=str, required=True)
    parser.add_argument("--sample-size", type=int, default=1000)
    parser.add_argument("--full", action="store_true")
    parser.add_argument("--coord-method", type=str, default="sparse", choices=["sparse", "exact"])
    parser.add_argument("--coord-bucket-seconds", type=int, default=3600)
    parser.add_argument("--max-users", type=int, default=None)
    parser.add_argument("--sort-by-size", action="store_true")
    args = parser.parse_args()

    data_dir = Path(args.data_dir)
    cache_dir = Path(args.cache_dir)
    cache_dir.mkdir(parents=True, exist_ok=True)

    stats = pd.read_csv(args.stats_file)
    valid = stats[
        (stats["num_puppetmaster"] >= 10)
        & (stats["num_sockpuppets"] >= 5)
        & (stats["num_negatives"] / stats["num_positives"] >= 1.0)
    ].copy()
    valid["task_size"] = valid["num_positives"] + valid["num_negatives"]
    if args.max_users is not None:
        valid = valid[valid["task_size"] <= args.max_users]
    if args.sort_by_size:
        valid = valid.sort_values("task_size")
    if not args.full:
        valid = valid.head(args.sample_size)

    built = 0
    failed = 0
    for name in tqdm(valid["name"].tolist(), desc="Caching"):
        inv_path = data_dir / name
        try:
            build_or_load_raszewski_payload(
                inv_path,
                coord_method=args.coord_method,
                coord_bucket_seconds=args.coord_bucket_seconds,
                cache_dir=cache_dir,
                use_cache=True,
            )
            built += 1
        except Exception:
            failed += 1

    print(f"Prepared {built} payloads in {cache_dir}")
    if failed:
        print(f"Failed: {failed}")


if __name__ == "__main__":
    main()
