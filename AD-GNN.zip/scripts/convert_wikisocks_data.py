#!/usr/bin/env python3
"""
Convert wiki-socks dataset to activity log format.

Dataset: https://github.com/lraszewski/wiki-socks
Paper: Raszewski et al. "Detecting Sockpuppets on Wikipedia"

Schema (7 fields per contribution):
- timestamp: UTC time in ISO 8601 format
- revid: Unique revision identifier
- parentid: Prior revision's ID
- sock: Binary flag (1=sockpuppet, 0=legitimate user)
- user: Username
- page: Wikipedia article title
- message: Edit summary
"""

import argparse
import json
from pathlib import Path
from typing import List, Dict, Set
from glob import glob

import pandas as pd
from tqdm import tqdm


def load_investigation_files(data_dir: str) -> pd.DataFrame:
    """
    Load all investigation CSV files from wiki-socks dataset.

    Each CSV file represents one sockpuppet investigation.
    """
    data_path = Path(data_dir)
    csv_files = list(data_path.glob("*.csv"))

    if not csv_files:
        raise ValueError(f"No CSV files found in {data_dir}")

    print(f"Found {len(csv_files)} investigation files")

    all_contributions = []

    for csv_file in tqdm(csv_files, desc="Loading investigations"):
        try:
            # Load with proper dtypes as per wiki-socks documentation
            df = pd.read_csv(
                csv_file,
                dtype={
                    'revid': 'Int64',
                    'parentid': 'Int64',
                    'sock': 'Int64',
                    'user': str,
                    'page': str,
                    'message': str,
                },
                parse_dates=['timestamp'],
            )

            # Replace NaN in text fields with empty strings
            df['user'] = df['user'].fillna('')
            df['page'] = df['page'].fillna('')
            df['message'] = df['message'].fillna('')

            # Add investigation ID (filename without extension)
            df['investigation_id'] = csv_file.stem

            all_contributions.append(df)

        except Exception as e:
            print(f"Error loading {csv_file}: {e}")
            continue

    if not all_contributions:
        raise ValueError("No contributions loaded!")

    combined_df = pd.concat(all_contributions, ignore_index=True)

    print(f"\nLoaded {len(combined_df)} total contributions")
    print(f"  Sockpuppet edits: {(combined_df['sock'] == 1).sum()}")
    print(f"  Legitimate edits: {(combined_df['sock'] == 0).sum()}")

    return combined_df


def convert_to_activity_log(contributions_df: pd.DataFrame) -> pd.DataFrame:
    """
    Convert wiki-socks contributions to our activity log format.
    """
    activity_log = pd.DataFrame()

    # Filter out rows with invalid timestamps
    valid_mask = contributions_df['timestamp'].notna() & (contributions_df['timestamp'] != '\\n')
    contributions_df = contributions_df[valid_mask].copy()

    print(f"Filtered to {len(contributions_df)} events with valid timestamps")

    activity_log['user_id'] = contributions_df['user'].astype(str)
    activity_log['page_id'] = contributions_df['page'].astype(str)
    activity_log['timestamp'] = pd.to_datetime(contributions_df['timestamp'], errors='coerce')

    # Drop any remaining invalid timestamps
    activity_log = activity_log.dropna(subset=['timestamp'])

    # Optional: add event type based on edit summary
    activity_log['event_type'] = 'edit'

    # Sort by timestamp
    activity_log = activity_log.sort_values('timestamp').reset_index(drop=True)

    print(f"\nActivity log statistics:")
    print(f"  Total events: {len(activity_log)}")
    print(f"  Unique users: {activity_log['user_id'].nunique()}")
    print(f"  Unique pages: {activity_log['page_id'].nunique()}")

    if len(activity_log) > 0:
        print(f"  Time range: {activity_log['timestamp'].min()} to {activity_log['timestamp'].max()}")

    return activity_log


def extract_sockpuppet_groups(contributions_df: pd.DataFrame) -> List[List[str]]:
    """
    Extract sockpuppet groups from investigations.

    Group sockpuppets by investigation_id.
    Users with sock=1 in the same investigation are likely related.
    """
    # Get sockpuppet contributions only
    sockpuppets = contributions_df[contributions_df['sock'] == 1]

    # Group by investigation
    groups_dict: Dict[str, Set[str]] = {}

    for inv_id, inv_df in sockpuppets.groupby('investigation_id'):
        users = set(inv_df['user'].unique())
        if len(users) > 1:  # Only keep groups with 2+ users
            groups_dict[inv_id] = users

    # Convert to list of lists
    groups = [sorted(list(users)) for users in groups_dict.values()]

    return groups


def main():
    parser = argparse.ArgumentParser(
        description="Convert wiki-socks dataset to activity log format"
    )
    parser.add_argument(
        '--data-dir',
        type=str,
        required=True,
        help='Path to directory containing investigation CSV files',
    )
    parser.add_argument(
        '--output-log',
        type=str,
        default='data/raw/wikisocks_activity_log.csv',
        help='Output path for activity log',
    )
    parser.add_argument(
        '--output-labels',
        type=str,
        default='data/wikisocks_labels.json',
        help='Output path for labels JSON',
    )
    parser.add_argument(
        '--sockpuppets-only',
        action='store_true',
        help='Only include sockpuppet edits (sock=1) in activity log',
    )
    parser.add_argument(
        '--sample-investigations',
        type=int,
        help='Process only first N investigation files (for testing)',
    )

    args = parser.parse_args()

    print("=" * 70)
    print("Wiki-Socks Dataset Conversion")
    print("=" * 70)

    # Load investigation files
    print("\n1. Loading investigation files...")
    contributions_df = load_investigation_files(args.data_dir)

    # Sample if requested
    if args.sample_investigations:
        print(f"\nSampling {args.sample_investigations} investigations...")
        inv_ids = contributions_df['investigation_id'].unique()[:args.sample_investigations]
        contributions_df = contributions_df[contributions_df['investigation_id'].isin(inv_ids)]
        print(f"Sampled to {len(contributions_df)} contributions")

    # Filter to sockpuppets only if requested
    if args.sockpuppets_only:
        print("\nFiltering to sockpuppet edits only...")
        contributions_df = contributions_df[contributions_df['sock'] == 1]
        print(f"Filtered to {len(contributions_df)} sockpuppet edits")

    # Convert to activity log
    print("\n2. Converting to activity log format...")
    activity_log = convert_to_activity_log(contributions_df)

    # Save activity log
    output_log_path = Path(args.output_log)
    output_log_path.parent.mkdir(parents=True, exist_ok=True)

    if output_log_path.suffix == '.parquet':
        activity_log.to_parquet(output_log_path, index=False)
    else:
        activity_log.to_csv(output_log_path, index=False)

    print(f"\nSaved activity log to: {output_log_path}")

    # Extract sockpuppet groups
    print("\n3. Extracting sockpuppet groups...")
    groups = extract_sockpuppet_groups(contributions_df)

    print(f"Extracted {len(groups)} sockpuppet groups")

    if groups:
        sizes = [len(g) for g in groups]
        print(f"Size distribution:")
        print(f"  Min: {min(sizes)}")
        print(f"  Max: {max(sizes)}")
        print(f"  Mean: {sum(sizes)/len(sizes):.1f}")
        print(f"  Median: {sorted(sizes)[len(sizes)//2]}")

        # Show sample groups
        print(f"\nSample groups:")
        for i, group in enumerate(groups[:3]):
            print(f"  Group {i+1} ({len(group)} users): {group[:5]}{'...' if len(group) > 5 else ''}")

    # Save labels
    labels = {
        'positive_groups': groups,
        'metadata': {
            'source': 'wiki_socks',
            'total_groups': len(groups),
            'total_users': sum(len(g) for g in groups),
            'total_investigations': contributions_df['investigation_id'].nunique(),
            'sockpuppets_only': args.sockpuppets_only,
        }
    }

    output_labels_path = Path(args.output_labels)
    output_labels_path.parent.mkdir(parents=True, exist_ok=True)

    with open(output_labels_path, 'w') as f:
        json.dump(labels, f, indent=2)

    print(f"Saved labels to: {output_labels_path}")

    print("\n" + "=" * 70)
    print("Conversion complete!")
    print("=" * 70)
    print("\nNext steps:")
    print(f"  1. Build windows: python scripts/build_windows.py --input {args.output_log} --config configs/default.yaml --output data/processed/windows")
    print(f"  2. Train AD-GNN: python scripts/train_adgnn.py --windows data/processed/windows --labels {args.output_labels} --output results/positive_all/adgnn")
    print(f"  3. Test zero-shot: python scripts/evaluate_on_raszewski_fast.py --model results/positive_all/adgnn/best_model_global.pt")


if __name__ == '__main__':
    main()
