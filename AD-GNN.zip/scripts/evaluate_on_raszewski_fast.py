#!/usr/bin/env python3
"""
FAST evaluation of AD-GNN V3 on Raszewski ACL 2025 dataset

Strategy: Use PRETRAINED AD-GNN V3 for zero-shot prediction (no per-investigation training!)

This is much faster and tests the model's generalization ability.
"""

import pandas as pd
import numpy as np
from pathlib import Path
from sklearn.metrics import average_precision_score, roc_auc_score
import json
import argparse
import yaml
from tqdm import tqdm
import torch
import sys
import pickle
import hashlib
from typing import Optional

# Add src to path
sys.path.insert(0, str(Path(__file__).parent.parent / 'src'))

from community_deception.adgnn.data import build_hetero_graph
from community_deception.adgnn.model_disentangled import DisentangledDeceptionDetector
from community_deception.features import extract_user_features, normalize_features
from community_deception.graphs import build_graphs_adgnn, build_community_graph
from scipy.sparse import csr_matrix, triu

# Paths
RASZEWSKI_DATA = Path('data/raszewski_dataset/data')
STATS_FILE = Path('data/raszewski_dataset/stats.csv')
def parse_args():
    parser = argparse.ArgumentParser(description="Fast Raszewski evaluation (zero-shot)")
    parser.add_argument("--output", type=str, default="results/raszewski/adgnn_eval_fast")
    parser.add_argument("--device", type=str, default="mps")
    parser.add_argument("--model", type=str, default="results/positive_all/adgnn/best_model_global.pt")
    parser.add_argument("--sample-size", type=int, default=1000)
    parser.add_argument("--max-users", type=int, default=None,
                        help="Skip investigations with more than this many users (approx = positives+negatives).")
    parser.add_argument("--sort-by-size", action="store_true",
                        help="Process smaller investigations first for faster progress.")
    parser.add_argument("--coord-method", type=str, default="sparse", choices=["sparse", "exact"],
                        help="Coordination graph builder: sparse (bucketed) or exact (sliding window).")
    parser.add_argument("--coord-bucket-seconds", type=int, default=None,
                        help="Bucket size for sparse coordination. Defaults to coord delta (3600s).")
    parser.add_argument("--no-cache", action="store_true",
                        help="Disable graph/feature caching.")
    parser.add_argument("--cache-dir", type=str, default=None,
                        help="Cache directory for graphs/features. Defaults to <output>/cache.")
    return parser.parse_args()


args = parse_args()
OUTPUT_DIR = Path(args.output)
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

PRETRAINED_MODEL = Path(args.model)
CACHE_DIR = Path(args.cache_dir) if args.cache_dir else (OUTPUT_DIR / "cache")
CACHE_DIR.mkdir(parents=True, exist_ok=True)

COORD_DELTA_SECONDS = 3600
COORD_MIN_WEIGHT = 2
COMM_MIN_WEIGHT = 2
COMM_SIMILARITY = "cosine"
TEMPORAL_DECAY = False
DECAY_LAMBDA = 0.1
BURST_THRESHOLD_SECONDS = 300
CACHE_VERSION = 2

print("="*80)
print("FAST EVALUATION: AD-GNN V3 ON RASZEWSKI ACL 2025 DATASET")
print("="*80)
print()
print("Strategy: Use PRETRAINED model for zero-shot prediction")
print("Target to beat: AUPRC = 0.6221 (Reptile meta-learning)")
print(f"Model: {PRETRAINED_MODEL}")
print(f"Requested device: {args.device}")
print()


def _cache_key(inv_path: Path, feature_names, coord_method: str, coord_bucket_seconds: Optional[int]):
    stat = inv_path.stat()
    meta = {
        "cache_version": CACHE_VERSION,
        "path": str(inv_path),
        "size": stat.st_size,
        "mtime": stat.st_mtime,
        "coord_method": coord_method,
        "coord_bucket_seconds": coord_bucket_seconds,
        "coord_delta_seconds": COORD_DELTA_SECONDS,
        "coord_min_weight": COORD_MIN_WEIGHT,
        "comm_min_weight": COMM_MIN_WEIGHT,
        "comm_similarity": COMM_SIMILARITY,
        "temporal_decay": TEMPORAL_DECAY,
        "decay_lambda": DECAY_LAMBDA,
        "burst_threshold_seconds": BURST_THRESHOLD_SECONDS,
        "features": list(feature_names),
    }
    meta_blob = json.dumps(meta, sort_keys=True).encode("utf-8")
    key = hashlib.sha1(meta_blob).hexdigest()[:12]
    return key, meta


def _load_cache(cache_path: Path, expected_meta: dict):
    if not cache_path.exists():
        return None
    try:
        with open(cache_path, "rb") as f:
            payload = pickle.load(f)
        if payload.get("meta") != expected_meta:
            return None
        return payload
    except Exception:
        return None


def _save_cache(cache_path: Path, payload: dict):
    try:
        with open(cache_path, "wb") as f:
            pickle.dump(payload, f, protocol=pickle.HIGHEST_PROTOCOL)
    except Exception:
        return


def build_coordination_graph_sparse(
    df: pd.DataFrame,
    delta_seconds: int = 3600,
    min_weight: int = 2,
) -> pd.DataFrame:
    """Approximate bursty coordination via sparse user-(page,bucket) co-activity."""
    if df.empty:
        return pd.DataFrame(columns=["source", "target", "weight", "burst_count", "temporal_weight"])

    timestamps = pd.to_datetime(df["timestamp"])
    ts_sec = (timestamps.astype("int64") // 10**9).astype(np.int64)
    bucket = (ts_sec // delta_seconds).astype(np.int64)

    users = sorted(df["user_id"].unique(), key=str)
    user_to_idx = {u: i for i, u in enumerate(users)}
    rows = df["user_id"].map(user_to_idx).values

    page_codes, _ = pd.factorize(df["page_id"], sort=False)
    group_codes, _ = pd.factorize(pd.MultiIndex.from_arrays([page_codes, bucket]), sort=False)

    if len(rows) == 0:
        return pd.DataFrame(columns=["source", "target", "weight", "burst_count", "temporal_weight"])

    pairs = np.column_stack([rows, group_codes])
    pairs = np.unique(pairs, axis=0)

    X = csr_matrix(
        (np.ones(len(pairs), dtype=np.float32), (pairs[:, 0], pairs[:, 1])),
        shape=(len(users), int(group_codes.max() + 1)),
        dtype=np.float32,
    )

    W = X @ X.T
    W.setdiag(0)
    W.eliminate_zeros()

    W_upper = triu(W, k=1)
    edge_rows, edge_cols = W_upper.nonzero()
    weights = W_upper.data

    if len(weights) == 0:
        return pd.DataFrame(columns=["source", "target", "weight", "burst_count", "temporal_weight"])

    mask = weights >= min_weight
    edge_rows = edge_rows[mask]
    edge_cols = edge_cols[mask]
    weights = weights[mask]

    edges = pd.DataFrame({
        "source": [users[i] for i in edge_rows],
        "target": [users[i] for i in edge_cols],
        "weight": weights,
    })

    if edges.empty:
        return pd.DataFrame(columns=["source", "target", "weight", "burst_count", "temporal_weight"])

    edges["burst_count"] = 0.0
    edges["temporal_weight"] = edges["weight"].astype(float)
    return edges


def build_graph_from_investigation(
    inv_path: Path,
    df: pd.DataFrame,
    coord_method: str = "sparse",
    coord_bucket_seconds: Optional[int] = None,
    use_cache: bool = True,
):
    """Build graphs and features compatible with AD-GNN checkpoint, with caching."""
    # Adapt schema to window format
    work_df = df.copy()
    work_df["timestamp"] = pd.to_datetime(
        work_df["timestamp"], format="mixed", utc=True, errors="coerce"
    )
    work_df = work_df.dropna(subset=["timestamp"])
    work_df["user_id"] = work_df["user"]
    work_df["page_id"] = work_df["page"]

    # Feature extraction (match training)
    feature_names = [
        "edit_count",
        "unique_pages",
        "pages_per_day",
        "temporal_spread",
        "activity_concentration",
    ]
    cache_key, meta = _cache_key(inv_path, feature_names, coord_method, coord_bucket_seconds)
    cache_path = CACHE_DIR / f"{inv_path.stem}_{cache_key}.pkl"

    if use_cache:
        cached = _load_cache(cache_path, meta)
        if cached is not None:
            return cached["comm_edges"], cached["coord_edges"], cached["user_features"]

    # Build graphs with AD-GNN alignment
    comm_edges = build_community_graph(
        work_df,
        min_weight=COMM_MIN_WEIGHT,
        similarity=COMM_SIMILARITY,
        temporal_decay=TEMPORAL_DECAY,
        decay_lambda=DECAY_LAMBDA,
    )

    if coord_method == "sparse":
        bucket_seconds = coord_bucket_seconds or COORD_DELTA_SECONDS
        coord_edges = build_coordination_graph_sparse(
            work_df,
            delta_seconds=bucket_seconds,
            min_weight=COORD_MIN_WEIGHT,
        )
        # AD-GNN paradox alignment: comm = bursty coordination, coord = long-term similarity
        # In sparse mode, use bucketed coordination as comm and co-edit similarity as coord.
        comm_edges, coord_edges = coord_edges, comm_edges
    else:
        comm_edges, coord_edges = build_graphs_adgnn(
            work_df,
            coord_delta_seconds=COORD_DELTA_SECONDS,
            coord_min_weight=COORD_MIN_WEIGHT,
            comm_min_weight=COMM_MIN_WEIGHT,
            comm_similarity=COMM_SIMILARITY,
            temporal_decay=TEMPORAL_DECAY,
            decay_lambda=DECAY_LAMBDA,
            burst_threshold_seconds=BURST_THRESHOLD_SECONDS,
        )

    user_features = extract_user_features(work_df, feature_names)
    user_features = normalize_features(user_features)

    if use_cache:
        payload = {
            "meta": meta,
            "comm_edges": comm_edges,
            "coord_edges": coord_edges,
            "user_features": user_features,
        }
        _save_cache(cache_path, payload)

    return comm_edges, coord_edges, user_features


def evaluate_investigation_zeroshot(model, inv_path: Path, inv_df, puppetmaster, device='mps'):
    """
    Use PRETRAINED model to predict (NO training!)
    """

    # Build graphs
    try:
        comm_edges, coord_edges, user_features = build_graph_from_investigation(
            inv_path=inv_path,
            df=inv_df,
            coord_method=args.coord_method,
            coord_bucket_seconds=args.coord_bucket_seconds,
            use_cache=not args.no_cache,
        )
        if not user_features:
            return None
        hetero_graph, user_list = build_hetero_graph(comm_edges, coord_edges, user_features)

    except Exception as e:
        return None

    # Move graph to device
    hetero_graph = hetero_graph.to(device)

    # Create user ID to index mapping
    user_to_idx = {u: i for i, u in enumerate(user_list)}

    # Get test users (all except puppetmaster)
    test_df = inv_df[inv_df['user'] != puppetmaster]

    if len(test_df) == 0:
        return None

    # Predict on test users
    test_users = test_df['user'].unique()
    test_labels = []
    test_preds = []

    model.eval()
    with torch.no_grad():
        for test_user in test_users:
            if test_user not in user_to_idx:
                continue

            test_user_idx = user_to_idx[test_user]
            true_label = int(test_df[test_df['user'] == test_user]['sock'].iloc[0])

            # Create groups containing this user for prediction
            # Average over multiple group compositions for robustness
            user_preds = []
            for _ in range(5):
                group_size = min(3, len(user_list))
                other_users = [i for i in range(len(user_list)) if i != test_user_idx]
                if other_users and group_size >= 2:
                    selected = [test_user_idx] + list(np.random.choice(other_users, size=min(2, len(other_users)), replace=False))

                    # Forward pass
                    probs, _ = model(hetero_graph, [selected])
                    prob = probs.item()
                    user_preds.append(prob)

            if user_preds:
                test_labels.append(true_label)
                test_preds.append(np.mean(user_preds))

    if len(test_labels) < 2 or len(np.unique(test_labels)) < 2:
        return None

    # Compute metrics
    auprc = average_precision_score(test_labels, test_preds)
    auroc = roc_auc_score(test_labels, test_preds)

    return {
        'auprc': auprc,
        'auroc': auroc,
        'num_test': len(test_df),
        'num_test_positives': sum(test_labels),
        'num_test_negatives': len(test_labels) - sum(test_labels)
    }


# Load pretrained model
print(f"Loading pretrained model from: {PRETRAINED_MODEL}")

device = args.device
if device == "mps" and not torch.backends.mps.is_available():
    print("MPS not available, using CPU")
    device = "cpu"
elif device == "cuda" and not torch.cuda.is_available():
    print("CUDA not available, using CPU")
    device = "cpu"

print(f"Using device: {device}")

# Create model
model = DisentangledDeceptionDetector(
    in_channels=5,
    hidden_channels=96,
    num_layers=4,
    dropout=0.3,
    disentangle_weight=0.1,
)

# Load pretrained weights
checkpoint = torch.load(PRETRAINED_MODEL, map_location=device)
if isinstance(checkpoint, dict) and 'model_state_dict' in checkpoint:
    model.load_state_dict(checkpoint['model_state_dict'])
else:
    model.load_state_dict(checkpoint)

model = model.to(device)
model.eval()

print("✅ Model loaded successfully")
print()

# Save config
config = {
    "dataset": {
        "data_dir": str(RASZEWSKI_DATA),
        "stats_file": str(STATS_FILE),
    },
    "model_checkpoint": str(PRETRAINED_MODEL),
    "device": device,
    "sample_size": int(args.sample_size),
    "max_users": args.max_users,
    "sort_by_size": bool(args.sort_by_size),
    "mode": "fast_zero_shot",
    "coord_method": args.coord_method,
    "coord_bucket_seconds": args.coord_bucket_seconds,
    "cache_dir": str(CACHE_DIR),
    "cache_enabled": bool(not args.no_cache),
    "graph_params": {
        "coord_delta_seconds": COORD_DELTA_SECONDS,
        "coord_min_weight": COORD_MIN_WEIGHT,
        "comm_min_weight": COMM_MIN_WEIGHT,
        "comm_similarity": COMM_SIMILARITY,
        "temporal_decay": TEMPORAL_DECAY,
        "decay_lambda": DECAY_LAMBDA,
        "burst_threshold_seconds": BURST_THRESHOLD_SECONDS,
    },
    "features": [
        "edit_count",
        "unique_pages",
        "pages_per_day",
        "temporal_spread",
        "activity_concentration",
    ],
}
with open(OUTPUT_DIR / "config.yaml", "w") as f:
    yaml.safe_dump(config, f, sort_keys=False)

# Load stats
stats = pd.read_csv(STATS_FILE)
print(f"Total investigations: {len(stats)}")

# Filter valid investigations
valid_investigations = stats[
    (stats['num_puppetmaster'] >= 10) &
    (stats['num_sockpuppets'] >= 5) &
    (stats['num_negatives'] / stats['num_positives'] >= 1.0)
]

print(f"Valid investigations: {len(valid_investigations)}")
print()

# Build task size (approx users)
valid_investigations = valid_investigations.copy()
valid_investigations["task_size"] = valid_investigations["num_positives"] + valid_investigations["num_negatives"]

if args.max_users is not None:
    valid_investigations = valid_investigations[valid_investigations["task_size"] <= args.max_users]

if args.sort_by_size:
    valid_investigations = valid_investigations.sort_values("task_size")

# Evaluate on sample
SAMPLE_SIZE = args.sample_size
sample_invs = valid_investigations.head(SAMPLE_SIZE)

print(f"Running ZERO-SHOT evaluation on {len(sample_invs)} investigations...")
print()

results = []

for idx, row in tqdm(sample_invs.iterrows(), total=len(sample_invs), desc="Evaluating"):
    inv_file = RASZEWSKI_DATA / row['name']

    try:
        df = pd.read_csv(inv_file)
    except Exception as e:
        continue

    # Find puppetmaster
    sock_users = df[df['sock'] == 1]['user'].value_counts()
    if len(sock_users) == 0:
        continue

    puppetmaster = sock_users.index[0]

    # Zero-shot evaluation
    try:
        metrics = evaluate_investigation_zeroshot(model, inv_file, df, puppetmaster, device=device)

        if metrics:
            metrics['investigation'] = inv_file.name
            results.append(metrics)

    except Exception as e:
        continue

# Save and report results
results_df = pd.DataFrame(results)
results_filename = f"zeroshot_results_sample_{len(sample_invs)}.csv"
results_df.to_csv(OUTPUT_DIR / results_filename, index=False)

print("\n" + "="*80)
print(f"ZERO-SHOT EVALUATION COMPLETE - {len(results)} investigations")
print("="*80)

if len(results) > 0:
    mean_auprc = results_df['auprc'].mean()
    std_auprc = results_df['auprc'].std()
    mean_auroc = results_df['auroc'].mean()
    std_auroc = results_df['auroc'].std()

    print(f"\nAD-GNN V3 Zero-Shot Performance:")
    print(f"  Mean AUPRC: {mean_auprc:.4f} ± {std_auprc:.4f}")
    print(f"  Mean AUROC: {mean_auroc:.4f} ± {std_auroc:.4f}")
    print()
    print("Raszewski Results (for comparison):")
    print(f"  Reptile (meta-learning): AUPRC = 0.6221")
    print(f"  Standard Encoder:        AUPRC = 0.5067")
    print(f"  RoBERTa:                 AUPRC = 0.5045")
    print()

    if mean_auprc > 0.6221:
        improvement = ((mean_auprc - 0.6221) / 0.6221) * 100
        print(f"🎉 WE BEAT RASZEWSKI! +{improvement:.1f}% improvement!")
        print(f"   Our pretrained model generalizes better than their meta-learning!")
    else:
        gap = ((0.6221 - mean_auprc) / 0.6221) * 100
        print(f"Gap to Raszewski: -{gap:.1f}%")
        print(f"Note: This is zero-shot (no training per task)")

    print()
    print(f"Results saved to: {OUTPUT_DIR / results_filename}")

    # Save summary
    summary = {
        'evaluation_type': 'zero-shot',
        'num_investigations': len(results),
        'mean_auprc': float(mean_auprc),
        'std_auprc': float(std_auprc),
        'mean_auroc': float(mean_auroc),
        'std_auroc': float(std_auroc),
        'target_auprc': 0.6221,
        'beats_target': bool(mean_auprc > 0.6221),
        'sample_size': int(len(sample_invs)),
        'device': device,
        'model_checkpoint': str(PRETRAINED_MODEL),
    }

    with open(OUTPUT_DIR / 'summary.json', 'w') as f:
        json.dump(summary, f, indent=2)

else:
    print("\nNo investigations successfully processed!")

print()
print("="*80)
print("ADVANTAGES:")
print("="*80)
print("1. MUCH FASTER: Zero-shot evaluation (no training per investigation)")
print("2. Tests generalization: Pretrained model transfers to new data")
print("3. Scalable: Can easily run on all 13,549 investigations")
