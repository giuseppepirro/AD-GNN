#!/usr/bin/env python3
"""Build temporal windows from an activity log."""

import argparse
from pathlib import Path
import sys

import yaml

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from community_deception.io import read_activity_log, validate_activity_log
from community_deception.windows import WindowSlicer


def main() -> None:
    parser = argparse.ArgumentParser(description="Build temporal windows from an activity log")
    parser.add_argument("--input", type=str, required=True, help="Path to activity log CSV or Parquet")
    parser.add_argument("--output", type=str, required=True, help="Output directory for window parquet files")
    parser.add_argument("--config", type=str, default=None, help="Optional YAML config with windowing settings")
    parser.add_argument("--window-size-days", type=int, default=None)
    parser.add_argument("--step-days", type=int, default=None)
    parser.add_argument("--min-user-activity", type=int, default=None)
    args = parser.parse_args()

    config = {}
    if args.config:
        with open(args.config, "r") as f:
            config = yaml.safe_load(f) or {}

    windowing = config.get("windowing", {})
    window_size_days = args.window_size_days or windowing.get("window_size_days", 14)
    step_days = args.step_days or windowing.get("step_days", 7)
    min_user_activity = (
        args.min_user_activity
        if args.min_user_activity is not None
        else windowing.get("min_user_activity", 5)
    )

    df = read_activity_log(args.input)
    validate_activity_log(df)

    slicer = WindowSlicer(
        window_size_days=window_size_days,
        step_days=step_days,
        min_user_activity=min_user_activity,
    )
    metadata = slicer.slice_and_save(df, args.output)

    print(f"Created {len(metadata)} windows in {args.output}")


if __name__ == "__main__":
    main()
